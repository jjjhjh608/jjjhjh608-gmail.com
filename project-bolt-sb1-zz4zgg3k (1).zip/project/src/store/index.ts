import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { BusinessProfile, ChatMessage, BusinessReport, SavedInsight, DailyTip } from '../types';

interface User {
  id: string;
  email: string;
  full_name: string;
  created_at: string;
  is_pro?: boolean;
  last_tip_date?: string | null;
  last_tip?: string | null;
}

interface AppState {
  user: User | null;
  businessProfile: BusinessProfile | null;
  chatMessages: ChatMessage[];
  reports: BusinessReport[];
  savedInsights: SavedInsight[];
  dailyTips: DailyTip[];
  setUser: (user: User | null) => void;
  setBusinessProfile: (profile: BusinessProfile | null) => void;
  addChatMessage: (message: ChatMessage) => void;
  clearChatMessages: () => void;
  addReport: (report: BusinessReport) => void;
  addSavedInsight: (insight: SavedInsight) => void;
  addDailyTip: (tip: DailyTip) => void;
  markTipAsUseful: (tipId: string) => void;
  clearAll: () => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      user: null,
      businessProfile: null,
      chatMessages: [],
      reports: [],
      savedInsights: [],
      dailyTips: [],
      setUser: (user) => set({ user }),
      setBusinessProfile: (profile) => set({ businessProfile: profile }),
      addChatMessage: (message) =>
        set((state) => ({ chatMessages: [...state.chatMessages, message] })),
      clearChatMessages: () => set({ chatMessages: [] }),
      addReport: (report) =>
        set((state) => ({ reports: [...state.reports, report] })),
      addSavedInsight: (insight) =>
        set((state) => ({ savedInsights: [...state.savedInsights, insight] })),
      addDailyTip: (tip) =>
        set((state) => ({ dailyTips: [...state.dailyTips, tip] })),
      markTipAsUseful: (tipId) =>
        set((state) => ({
          dailyTips: state.dailyTips.map((tip) =>
            tip.id === tipId ? { ...tip, is_useful: true } : tip
          ),
        })),
      clearAll: () => set({
        user: null,
        businessProfile: null,
        chatMessages: [],
        reports: [],
        savedInsights: [],
        dailyTips: []
      })
    }),
    {
      name: 'business-advisor-storage',
      partialize: (state) => ({
        // Only persist businessProfile and savedInsights
        businessProfile: state.businessProfile,
        savedInsights: state.savedInsights
      })
    }
  )
);