import React from 'react';
import { motion } from 'framer-motion';
import type { LucideIcon } from 'lucide-react';

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  delay?: number;
}

export function FeatureCard({ icon: Icon, title, description, delay = 0 }: FeatureCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      viewport={{ once: true }}
      className="feature-card"
    >
      <div className="flex items-center justify-center w-16 h-16 mb-6 rounded-xl bg-blue-100">
        <Icon className="h-8 w-8 text-blue-600" />
      </div>
      <h3 className="feature-card h3">
        {title}
      </h3>
      <p className="feature-card p">
        {description}
      </p>
    </motion.div>
  );
}