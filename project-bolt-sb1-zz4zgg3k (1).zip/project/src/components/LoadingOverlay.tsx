import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LineChart, Target, BarChart, Sparkles, CheckCircle, ArrowRight } from 'lucide-react';

const phases = [
  {
    text: 'מנתח את הנתונים שלך',
    icon: LineChart,
    description: 'מעבד את המידע העסקי שלך בצורה חכמה'
  },
  {
    text: 'בודק מגמות בתחום שלך',
    icon: Target,
    description: 'מזהה הזדמנויות ואתגרים בשוק'
  },
  {
    text: 'מתאים קהל יעד',
    icon: BarChart,
    description: 'מגדיר את הלקוחות המושלמים עבורך'
  },
  {
    text: 'בוחן ערוצי שיווק',
    icon: Sparkles,
    description: 'מאתר את הדרכים הטובות ביותר להגיע ללקוחות'
  },
  {
    text: 'בונה אסטרטגיה',
    icon: CheckCircle,
    description: 'מגבש תוכנית פעולה מדויקת לעסק שלך'
  }
];

interface LoadingOverlayProps {
  onComplete?: () => void;
}

export function LoadingOverlay({ onComplete }: LoadingOverlayProps) {
  const [currentPhase, setCurrentPhase] = useState(0);
  const [dots, setDots] = useState('');

  useEffect(() => {
    const dotInterval = setInterval(() => {
      setDots(prev => prev.length >= 3 ? '' : prev + '.');
    }, 500);

    const phaseInterval = setInterval(() => {
      setCurrentPhase(prev => {
        if (prev === phases.length - 1) {
          clearInterval(phaseInterval);
          clearInterval(dotInterval);
          if (onComplete) {
            setTimeout(onComplete, 1000);
          }
          return prev;
        }
        return prev + 1;
      });
    }, 3000);

    return () => {
      clearInterval(dotInterval);
      clearInterval(phaseInterval);
    };
  }, [onComplete]);

  const progress = ((currentPhase + 1) / phases.length) * 100;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-gradient-to-br from-blue-900/50 to-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-white rounded-2xl shadow-xl w-full max-w-sm sm:max-w-lg relative overflow-hidden mx-4"
      >
        <div className="absolute top-0 left-0 w-full h-1">
          <motion.div
            className="h-full bg-gradient-to-r from-blue-500 to-blue-600"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>

        <div className="p-6 sm:p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentPhase}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex flex-col items-center text-center"
            >
              <motion.div
                animate={{
                  scale: [1, 1.2, 1],
                  rotate: [0, 360]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                className="mb-4 sm:mb-6"
              >
                {React.createElement(phases[currentPhase].icon, {
                  className: "w-12 h-12 sm:w-16 sm:h-16 text-blue-600"
                })}
              </motion.div>

              <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-2">
                {phases[currentPhase].text}{dots}
              </h3>
              
              <p className="text-base sm:text-lg text-gray-600">
                {phases[currentPhase].description}
              </p>

              <div className="w-full mt-6 sm:mt-8">
                <div className="flex justify-between text-sm text-gray-500 mb-2">
                  <span>שלב {currentPhase + 1} מתוך {phases.length}</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    transition={{ duration: 0.5 }}
                  />
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </motion.div>
    </motion.div>
  );
}