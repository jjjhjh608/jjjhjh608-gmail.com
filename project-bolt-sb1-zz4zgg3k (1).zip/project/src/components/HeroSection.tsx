import React from 'react';
import { motion } from 'framer-motion';
import { Brain, ArrowLeft } from 'lucide-react';

interface HeroSectionProps {
  onGetStarted: () => void;
}

export function HeroSection({ onGetStarted }: HeroSectionProps) {
  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-teal-600 via-blue-600 to-purple-600 py-20 sm:py-32">
      <div className="absolute inset-0">
        {/* Wave pattern overlay */}
        <div className="absolute inset-0 opacity-10">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0 25C20 25 20 75 40 75C60 75 60 25 80 25C100 25 100 75 120 75" 
                  stroke="currentColor" 
                  strokeWidth="0.5" 
                  fill="none"
                  className="text-white animate-pulse-slow" />
            <path d="M-20 45C0 45 0 95 20 95C40 95 40 45 60 45C80 45 80 95 100 95" 
                  stroke="currentColor" 
                  strokeWidth="0.5" 
                  fill="none"
                  className="text-white animate-pulse-slow" 
                  style={{ animationDelay: '1s' }} />
          </svg>
        </div>
        
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-white/10" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
            className="flex justify-center mb-8"
          >
            <div className="relative">
              <div className="absolute inset-0 bg-white/20 rounded-full blur-3xl opacity-30 animate-pulse" />
              <Brain className="h-24 w-24 text-white relative z-10" />
            </div>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-5xl sm:text-6xl font-bold text-white mb-6"
          >
            היועץ החכם לעסקים
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-xl sm:text-2xl text-white/90 mb-12 max-w-3xl mx-auto leading-relaxed"
          >
            קבל ייעוץ עסקי מותאם אישית תוך שניות – בדיוק לפי העסק שלך
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
          >
            <button
              onClick={onGetStarted}
              className="group relative inline-flex items-center justify-center px-8 py-4 text-lg font-medium text-blue-900 bg-white rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200 overflow-hidden"
            >
              <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-blue-50 to-purple-50 opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
              <span className="relative flex items-center">
                קבל אבחון חכם לעסק שלך
                <ArrowLeft className="mr-2 h-5 w-5" />
              </span>
            </button>

            <a
              href="#features"
              className="text-white/90 hover:text-white transition-colors px-6 py-4"
            >
              גלה עוד
            </a>
          </motion.div>
        </motion.div>
      </div>

      {/* Animated wave bottom */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg className="w-full h-24" viewBox="0 0 1440 54" preserveAspectRatio="none">
          <path 
            d="M0 27C240 53 480 27 720 27C960 27 1200 53 1440 27V54H0V27Z" 
            fill="white" 
            fillOpacity="0.3"
          />
          <path 
            d="M0 27C240 53 480 27 720 27C960 27 1200 53 1440 27V54H0V27Z" 
            fill="white" 
            fillOpacity="0.6"
            transform="translate(0 10)"
          />
          <path 
            d="M0 27C240 53 480 27 720 27C960 27 1200 53 1440 27V54H0V27Z" 
            fill="white"
            transform="translate(0 20)"
          />
        </svg>
      </div>
    </div>
  );
}