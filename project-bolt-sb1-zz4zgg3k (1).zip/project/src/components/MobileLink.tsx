import React from 'react';
import { motion } from 'framer-motion';
import { Smartphone, X } from 'lucide-react';

export function MobileLink() {
  const [isVisible, setIsVisible] = React.useState(true);
  const currentUrl = window.location.href;
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(currentUrl)}`;

  if (!isVisible) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="fixed bottom-4 right-4 z-50 bg-white p-6 rounded-2xl shadow-lg max-w-xs"
    >
      <button
        onClick={() => setIsVisible(false)}
        className="absolute top-2 right-2 text-gray-400 hover:text-gray-600"
        aria-label="סגור"
      >
        <X className="h-5 w-5" />
      </button>

      <div className="flex items-center gap-3 mb-4">
        <Smartphone className="h-6 w-6 text-blue-600" />
        <h3 className="text-lg font-semibold">גישה מהנייד</h3>
      </div>

      <div className="bg-gray-50 p-4 rounded-xl mb-4">
        <img
          src={qrCodeUrl}
          alt="QR Code"
          className="w-full h-auto"
          loading="lazy"
        />
      </div>

      <div className="text-sm text-gray-600 mb-4">
        סרוק את הקוד עם המצלמה בנייד שלך כדי לפתוח את האפליקציה
      </div>

      <a
        href={currentUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="block w-full bg-blue-600 text-white text-center py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
      >
        פתח בנייד
      </a>
    </motion.div>
  );
}