import React from 'react';
import { FileText } from 'lucide-react';
import { generateBusinessReport } from '../lib/pdf';
import type { BusinessProfile, ChatMessage } from '../types';

interface ReportButtonProps {
  profile: BusinessProfile;
  messages: ChatMessage[];
}

export function ReportButton({ profile, messages }: ReportButtonProps) {
  const handleGenerateReport = async () => {
    try {
      const { doc, fileName } = generateBusinessReport(profile, messages);
      doc.save(fileName);

      // Show success message
      const successMessage = document.createElement('div');
      successMessage.className = 'fixed bottom-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
      successMessage.textContent = 'הדוח נוצר בהצלחה!';
      document.body.appendChild(successMessage);

      setTimeout(() => {
        successMessage.remove();
      }, 3000);
    } catch (error) {
      console.error('Error generating PDF:', error);
      
      // Show error message
      const errorMessage = document.createElement('div');
      errorMessage.className = 'fixed bottom-4 right-4 bg-red-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
      errorMessage.textContent = 'שגיאה ביצירת הדוח';
      document.body.appendChild(errorMessage);

      setTimeout(() => {
        errorMessage.remove();
      }, 3000);
    }
  };

  return (
    <button
      onClick={handleGenerateReport}
      className="flex items-center gap-2 p-3 text-gray-700 hover:bg-blue-50 rounded-lg transition-colors w-full"
    >
      <FileText className="h-5 w-5 text-blue-600" />
      <span>הורד דוח PDF</span>
    </button>
  );
}