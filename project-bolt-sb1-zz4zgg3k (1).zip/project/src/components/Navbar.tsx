import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Brain, Menu, X, LogIn, UserPlus, LogOut } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppStore } from '../store';
import { supabase } from '../lib/supabase';

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { user, clearAll } = useAppStore();

  const menuItems = [
    { path: '/', label: 'ראשי' },
    { path: '/dashboard', label: 'פרופיל עסקי' },
    { path: '/ask-advisor', label: 'שאל את היועץ' },
    { path: '/smart-report', label: 'דוח חכם' },
    { path: '/my-insights', label: 'התובנות שלי' }
  ];

  React.useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  const handleLogout = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      clearAll();
      navigate('/');
    } catch (err) {
      console.error('Error signing out:', err);
    }
  };

  return (
    <nav className="bg-gradient-to-r from-blue-600 to-blue-700 shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-14 sm:h-16">
          <Link to="/" className="flex items-center space-x-2 rtl:space-x-reverse">
            <Brain className="h-6 w-6 sm:h-8 sm:w-8 text-white" />
            <span className="text-lg sm:text-xl font-bold text-white hidden sm:inline">היועץ החכם לעסקים</span>
            <span className="text-lg font-bold text-white sm:hidden">היועץ החכם</span>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-6 rtl:space-x-reverse">
            {menuItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`text-sm sm:text-base transition-colors ${
                  location.pathname === item.path
                    ? 'text-white font-semibold'
                    : 'text-blue-100 hover:text-white'
                }`}
              >
                {item.label}
              </Link>
            ))}

            {/* Auth Buttons */}
            {user ? (
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 px-4 py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-lg transition-colors"
              >
                <LogOut className="h-4 w-4" />
                <span>התנתק</span>
              </button>
            ) : (
              <div className="flex items-center gap-3">
                <Link
                  to="/register"
                  className="flex items-center gap-2 px-4 py-2 bg-white text-blue-600 rounded-lg hover:bg-blue-50 transition-colors"
                >
                  <UserPlus className="h-4 w-4" />
                  <span>הרשמה</span>
                </Link>
                <Link
                  to="/login"
                  className="flex items-center gap-2 px-4 py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-lg transition-colors"
                >
                  <LogIn className="h-4 w-4" />
                  <span>התחברות</span>
                </Link>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden text-white hover:text-blue-100 p-2"
            aria-label="תפריט"
          >
            {isMenuOpen ? (
              <X className="h-5 w-5 sm:h-6 sm:w-6" />
            ) : (
              <Menu className="h-5 w-5 sm:h-6 sm:w-6" />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden overflow-hidden"
            >
              <div className="py-2 border-t border-blue-500 space-y-1">
                {menuItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`block py-2 px-4 text-sm rounded-lg transition-colors ${
                      location.pathname === item.path
                        ? 'bg-blue-700 text-white font-semibold'
                        : 'text-blue-100 hover:bg-blue-600 hover:text-white'
                    }`}
                  >
                    {item.label}
                  </Link>
                ))}

                {/* Mobile Auth Buttons */}
                {user ? (
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center gap-2 py-2 px-4 text-sm text-blue-100 hover:bg-blue-600 hover:text-white rounded-lg transition-colors"
                  >
                    <LogOut className="h-4 w-4" />
                    <span>התנתק</span>
                  </button>
                ) : (
                  <>
                    <Link
                      to="/register"
                      className="block py-2 px-4 text-sm text-blue-100 hover:bg-blue-600 hover:text-white rounded-lg transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <UserPlus className="h-4 w-4" />
                        <span>הרשמה</span>
                      </div>
                    </Link>
                    <Link
                      to="/login"
                      className="block py-2 px-4 text-sm text-blue-100 hover:bg-blue-600 hover:text-white rounded-lg transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <LogIn className="h-4 w-4" />
                        <span>התחברות</span>
                      </div>
                    </Link>
                  </>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </nav>
  );
}