import React from 'react';
import { motion } from 'framer-motion';
import { Users, TrendingUp, Clock, CheckCircle } from 'lucide-react';

const stats = [
  {
    icon: Users,
    number: '1,500+',
    label: 'עסקים מלווים'
  },
  {
    icon: TrendingUp,
    number: '92%',
    label: 'דיוק בהתאמת ייעוץ'
  },
  {
    icon: Clock,
    number: '24/7',
    label: 'זמינות מלאה'
  },
  {
    icon: CheckCircle,
    number: '45%',
    label: 'עלייה בהכנסות'
  }
];

export function StatsSection() {
  return (
    <div className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="flex justify-center mb-4">
                  <div className="p-3 bg-blue-100 rounded-full">
                    <Icon className="h-8 w-8 text-blue-600" />
                  </div>
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-2">
                  {stat.number}
                </div>
                <div className="text-gray-600">
                  {stat.label}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}