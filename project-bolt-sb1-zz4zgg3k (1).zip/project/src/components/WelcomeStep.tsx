import React from 'react';
import { motion } from 'framer-motion';
import { Brain } from 'lucide-react';

interface WelcomeStepProps {
  onNext: (name: string, stage: 'idea' | 'new' | 'existing') => void;
}

export function WelcomeStep({ onNext }: WelcomeStepProps) {
  const [name, setName] = React.useState('');
  const [stage, setStage] = React.useState<'idea' | 'new' | 'existing'>('existing');
  const [error, setError] = React.useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('נא להזין את שמך');
      return;
    }
    onNext(name, stage);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full max-w-lg mx-auto px-4 text-center"
    >
      <div className="flex justify-center mb-6 sm:mb-8">
        <div className="relative">
          <div className="absolute inset-0 bg-blue-100 rounded-full blur-2xl"></div>
          <Brain className="h-16 w-16 sm:h-20 sm:w-20 text-blue-600 relative z-10" />
        </div>
      </div>

      <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-3 sm:mb-4">
        ברוך הבא ליועץ החכם!
      </h2>
      
      <p className="text-base sm:text-lg text-gray-600 mb-6 sm:mb-8">
        בוא נכיר אותך ואת העסק שלך כדי שנוכל לתת לך את הייעוץ הטוב ביותר
      </p>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="name" className="block text-base sm:text-lg font-medium text-gray-700 mb-2">
            איך קוראים לך?
          </label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => {
              setName(e.target.value);
              setError('');
            }}
            placeholder="הכנס את שמך"
            className="w-full px-4 py-3 text-base sm:text-lg border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
          />
          {error && (
            <p className="mt-2 text-red-600 text-sm">{error}</p>
          )}
        </div>

        <div>
          <label className="block text-base sm:text-lg font-medium text-gray-700 mb-2">
            באיזה שלב העסק שלך?
          </label>
          <div className="grid grid-cols-1 gap-3">
            <button
              type="button"
              onClick={() => setStage('idea')}
              className={`p-4 rounded-xl border-2 transition-all duration-200 ${
                stage === 'idea'
                  ? 'border-blue-500 bg-blue-50 text-blue-700'
                  : 'border-gray-200 hover:border-blue-200'
              }`}
            >
              <div className="text-base sm:text-lg font-medium mb-1">רעיון עסקי</div>
              <div className="text-sm text-gray-600">
                יש לי רעיון ואני רוצה להפוך אותו לעסק
              </div>
            </button>

            <button
              type="button"
              onClick={() => setStage('new')}
              className={`p-4 rounded-xl border-2 transition-all duration-200 ${
                stage === 'new'
                  ? 'border-blue-500 bg-blue-50 text-blue-700'
                  : 'border-gray-200 hover:border-blue-200'
              }`}
            >
              <div className="text-base sm:text-lg font-medium mb-1">עסק חדש</div>
              <div className="text-sm text-gray-600">
                התחלתי לאחרונה או מתכנן להתחיל בקרוב
              </div>
            </button>

            <button
              type="button"
              onClick={() => setStage('existing')}
              className={`p-4 rounded-xl border-2 transition-all duration-200 ${
                stage === 'existing'
                  ? 'border-blue-500 bg-blue-50 text-blue-700'
                  : 'border-gray-200 hover:border-blue-200'
              }`}
            >
              <div className="text-base sm:text-lg font-medium mb-1">עסק קיים</div>
              <div className="text-sm text-gray-600">
                יש לי עסק פעיל ואני רוצה לשפר אותו
              </div>
            </button>
          </div>
        </div>

        <button
          type="submit"
          className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-3 sm:py-4 px-6 sm:px-8 rounded-xl text-base sm:text-lg font-medium hover:shadow-lg transition-all duration-200"
        >
          בוא נתחיל!
        </button>
      </form>
    </motion.div>
  );
}