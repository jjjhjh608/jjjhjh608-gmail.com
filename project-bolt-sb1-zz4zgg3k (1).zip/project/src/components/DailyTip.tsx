import React from 'react';
import { ThumbsUp, SkipForward } from 'lucide-react';
import { useAppStore } from '../store';
import type { DailyTip as DailyTipType } from '../types';

interface DailyTipProps {
  tip: DailyTipType;
}

export function DailyTip({ tip }: DailyTipProps) {
  const markTipAsUseful = useAppStore((state) => state.markTipAsUseful);

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h3 className="text-xl font-semibold mb-4">💡 טיפ יומי חכם</h3>
      <p className="text-gray-700 mb-4">{tip.content}</p>
      <div className="flex justify-end space-x-4">
        <button
          onClick={() => markTipAsUseful(tip.id)}
          className="flex items-center text-green-600 hover:text-green-700"
        >
          <ThumbsUp className="h-5 w-5 ml-1" />
          <span>שימושי</span>
        </button>
        <button className="flex items-center text-gray-500 hover:text-gray-600">
          <SkipForward className="h-5 w-5 ml-1" />
          <span>דלג</span>
        </button>
      </div>
    </div>
  );
}