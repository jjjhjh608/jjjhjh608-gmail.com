import React from 'react';
import { motion } from 'framer-motion';
import { Star } from 'lucide-react';

const testimonials = [
  {
    name: 'רונית כהן',
    business: 'סטודיו לעיצוב פנים',
    content: 'לא האמנתי שמחשב יבין את העסק שלי ככה! קיבלתי תובנות מדהימות שעזרו לי להגדיל את ההכנסות ב-40% תוך חודשיים.',
    image: 'https://images.unsplash.com/photo-1598257006458-087169a1f08d?w=150&h=150&fit=crop'
  },
  {
    name: 'אמיר לוי',
    business: 'מסעדה איטלקית',
    content: 'זה חסך לי אלפי שקלים של יועצים – וקיבלתי תוכנית מדויקת ומיידית! ההמלצות היו פרקטיות ומותאמות בדיוק לעסק שלי.',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop'
  },
  {
    name: 'מיכל ברק',
    business: 'חנות אופנה',
    content: 'היועץ החכם עזר לי להבין בדיוק איך לשפר את השיווק ולהגיע ללקוחות הנכונים. התוצאות לא איחרו לבוא!',
    image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&h=150&fit=crop'
  }
];

export function TestimonialsSection() {
  return (
    <div className="py-24 bg-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            מה הלקוחות שלנו אומרים
          </h2>
          <p className="text-xl text-gray-600">
            סיפורי הצלחה מבעלי עסקים כמוך
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              className="bg-white p-8 rounded-2xl shadow-soft-xl"
            >
              <div className="flex items-center mb-6">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-16 h-16 rounded-full object-cover mr-4"
                />
                <div>
                  <h4 className="text-lg font-semibold text-gray-900">
                    {testimonial.name}
                  </h4>
                  <p className="text-gray-600">
                    {testimonial.business}
                  </p>
                </div>
              </div>
              <div className="flex mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-gray-700 leading-relaxed">
                {testimonial.content}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}