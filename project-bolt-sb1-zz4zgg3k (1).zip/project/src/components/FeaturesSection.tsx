import React from 'react';
import { motion } from 'framer-motion';
import { LineChart, Target, BarChart, Users } from 'lucide-react';

const features = [
  {
    icon: LineChart,
    title: 'מערכת ניתוח מתקדמת',
    description: 'מערכת חכמה שמנתחת את העסק שלך ומספקת המלצות מדויקות ורלוונטיות'
  },
  {
    icon: Target,
    title: 'ניתוח מקצועי של העסק',
    description: 'ניתוח מעמיק של נתוני העסק, זיהוי הזדמנויות ואתגרים'
  },
  {
    icon: BarChart,
    title: 'התאמה אישית מלאה',
    description: 'כל המלצה מותאמת במיוחד לסוג העסק, התחום והאתגרים הייחודיים שלך'
  },
  {
    icon: Users,
    title: 'המלצות פעולה ישימות',
    description: 'קבל צעדים מעשיים וברורים שתוכל ליישם כבר היום כדי לקדם את העסק'
  }
];

export function FeaturesSection() {
  return (
    <div className="py-24 bg-gradient-to-b from-white to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            למה לבחור במערכת הניתוח שלנו?
          </h2>
          <p className="text-xl text-gray-600">
            כי הגיע הזמן לקבל ייעוץ אמיתי שמבוסס על נתונים ולא על ניחושים
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2 }}
                className="bg-white p-8 rounded-2xl shadow-soft-xl hover:shadow-soft-2xl transition-all duration-300"
              >
                <div className="flex items-center justify-center w-16 h-16 mb-6 rounded-xl bg-blue-100">
                  <Icon className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  {feature.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}