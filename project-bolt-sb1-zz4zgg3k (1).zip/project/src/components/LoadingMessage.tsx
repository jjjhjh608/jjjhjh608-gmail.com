import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LineChart } from 'lucide-react';

interface LoadingMessageProps {
  message?: string;
}

export function LoadingMessage({ message = 'מעבד את השאלה שלך' }: LoadingMessageProps) {
  const [dots, setDots] = useState('');
  const [currentPhase, setCurrentPhase] = useState(0);

  const phases = [
    'מנתח את השאלה',
    'מעבד מידע עסקי',
    'מכין תשובה מותאמת אישית',
    'מוודא דיוק ורלוונטיות'
  ];

  useEffect(() => {
    const dotInterval = setInterval(() => {
      setDots(prev => prev.length >= 3 ? '' : prev + '.');
    }, 500);

    const phaseInterval = setInterval(() => {
      setCurrentPhase(prev => (prev + 1) % phases.length);
    }, 3000);

    return () => {
      clearInterval(dotInterval);
      clearInterval(phaseInterval);
    };
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="bg-white p-6 rounded-lg shadow-md max-w-md mx-auto"
    >
      <div className="flex justify-center mb-4">
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 180, 360]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <LineChart className="h-12 w-12 text-blue-600" />
        </motion.div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={currentPhase}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="text-center"
        >
          <h3 className="text-xl font-semibold text-gray-800 mb-2">
            {phases[currentPhase]}{dots}
          </h3>
          <p className="text-gray-600 text-sm">
            אני מעבד את המידע בקפידה כדי לתת לך את התשובה הטובה ביותר
          </p>
        </motion.div>
      </AnimatePresence>

      <div className="mt-4">
        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-blue-600"
            animate={{
              width: ['0%', '100%']
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "linear"
            }}
          />
        </div>
      </div>
    </motion.div>
  );
}