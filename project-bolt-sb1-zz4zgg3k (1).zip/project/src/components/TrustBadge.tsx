import React from 'react';
import { motion } from 'framer-motion';

interface TrustBadgeProps {
  icon: React.ReactNode;
  number: string;
  label: string;
  delay?: number;
}

export function TrustBadge({ icon, number, label, delay = 0 }: TrustBadgeProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      viewport={{ once: true }}
      className="flex flex-col items-center text-center"
    >
      <div className="mb-3 text-blue-600">
        {icon}
      </div>
      <div className="text-3xl font-bold text-gray-900 mb-1">
        {number}
      </div>
      <div className="text-gray-600">
        {label}
      </div>
    </motion.div>
  );
}