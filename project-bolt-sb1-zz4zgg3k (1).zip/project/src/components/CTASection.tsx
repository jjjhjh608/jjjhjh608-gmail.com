import React from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft } from 'lucide-react';

interface CTASectionProps {
  onGetStarted: () => void;
}

export function CTASection({ onGetStarted }: CTASectionProps) {
  return (
    <div className="relative py-24 bg-gradient-to-br from-teal-600 via-blue-600 to-purple-600 text-white overflow-hidden">
      {/* Animated wave background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 opacity-10">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0 25C20 25 20 75 40 75C60 75 60 25 80 25C100 25 100 75 120 75" 
                  stroke="currentColor" 
                  strokeWidth="0.5" 
                  fill="none"
                  className="text-white animate-pulse-slow" />
            <path d="M-20 45C0 45 0 95 20 95C40 95 40 45 60 45C80 45 80 95 100 95" 
                  stroke="currentColor" 
                  strokeWidth="0.5" 
                  fill="none"
                  className="text-white animate-pulse-slow" 
                  style={{ animationDelay: '1s' }} />
          </svg>
        </div>
        
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-white/10" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <h2 className="text-4xl font-bold mb-6">
            מוכן להצעיד את העסק שלך קדימה?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            התחל עכשיו – זה פשוט, מהיר וחכם
          </p>
          <button
            onClick={onGetStarted}
            className="inline-flex items-center px-8 py-4 text-lg font-medium bg-white text-blue-600 rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200"
          >
            קבל את הייעוץ שלך
            <ArrowLeft className="mr-2 h-5 w-5" />
          </button>
        </motion.div>
      </div>
    </div>
  );
}