import React from 'react';
import { motion } from 'framer-motion';
import { ChevronDown } from 'lucide-react';

const faqs = [
  {
    question: 'איך היועץ החכם יכול לעזור לעסק שלי?',
    answer: 'היועץ החכם משתמש בבינה מלאכותית מתקדמת כדי לנתח את העסק שלך ולספק המלצות מותאמות אישית בתחומי השיווק, המכירות, התפעול והאסטרטגיה. הוא זמין 24/7 ויכול לענות על שאלות ספציפיות או לתת ייעוץ כללי להתפתחות העסק.'
  },
  {
    question: 'האם השירות באמת חינמי?',
    answer: 'כן! הגרסה הבסיסית של היועץ החכם היא לגמרי חינמית. היא כוללת ניתוח ראשוני של העסק, המלצות בסיסיות וטיפים יומיים. למשתמשים שרוצים יותר, יש לנו גם תכנית פרימיום עם תכונות מתקדמות.'
  },
  {
    question: 'האם המידע שלי מאובטח?',
    answer: 'בהחלט! אנחנו משתמשים בטכנולוגיות הצפנה מתקדמות ומקפידים על סטנדרטים גבוהים של אבטחת מידע. המידע שלך מאוחסן בשרתים מאובטחים ולעולם לא נשתף אותו עם צד שלישי ללא הסכמתך.'
  },
  {
    question: 'כמה זמן לוקח לקבל תוצאות?',
    answer: 'היועץ החכם מספק תובנות ראשוניות תוך דקות ספורות מרגע מילוי השאלון. עם זאת, כדי לראות תוצאות משמעותיות בעסק, מומלץ ליישם את ההמלצות באופן עקבי לאורך זמן ולהמשיך להתייעץ עם המערכת.'
  }
];

export function FAQ() {
  return (
    <div className="py-24 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            שאלות נפוצות
          </h2>
          <p className="text-xl text-gray-600">
            כל מה שרצית לדעת על היועץ החכם
          </p>
        </motion.div>

        <div className="space-y-6">
          {faqs.map((faq, index) => (
            <motion.details
              key={faq.question}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group bg-white rounded-2xl shadow-soft-xl"
            >
              <summary className="flex justify-between items-center p-6 cursor-pointer list-none">
                <h3 className="text-lg font-semibold text-gray-900">
                  {faq.question}
                </h3>
                <ChevronDown className="h-5 w-5 text-gray-500 transform transition-transform group-open:rotate-180" />
              </summary>
              <div className="px-6 pb-6">
                <p className="text-gray-600 leading-relaxed">
                  {faq.answer}
                </p>
              </div>
            </motion.details>
          ))}
        </div>
      </div>
    </div>
  );
}