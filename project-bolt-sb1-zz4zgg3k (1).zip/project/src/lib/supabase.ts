import { createClient } from '@supabase/supabase-js';
import type { Database } from '../types/supabase';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

console.log('Initializing Supabase client with:', {
  url: supabaseUrl,
  hasAnonKey: !!supabaseAnonKey
});

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storage: window.localStorage,
    flowType: 'pkce',
    debug: true,
    onAuthStateChange: (event, session) => {
      console.log('Auth state changed:', event, { hasSession: !!session });
      
      if (event === 'SIGNED_IN' && session?.user) {
        console.log('User signed in, creating profile if needed');
        createUserProfileIfNeeded(session.user);
      }
    }
  },
  global: {
    headers: {
      'X-Client-Info': 'smart-business-advisor@1.0.0'
    }
  }
});

// Helper function to retry failed operations
export async function retryOperation<T>(
  operation: () => Promise<T>,
  maxRetries = 3,
  initialDelay = 1000
): Promise<T> {
  let lastError: Error | null = null;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      console.log(`Attempting operation (attempt ${attempt}/${maxRetries})`);
      const result = await operation();
      console.log('Operation succeeded');
      return result;
    } catch (err) {
      lastError = err instanceof Error ? err : new Error(String(err));
      console.error(`Operation failed (attempt ${attempt}/${maxRetries}):`, lastError);
      
      if (attempt < maxRetries) {
        const delay = initialDelay * Math.pow(2, attempt - 1);
        console.log(`Retrying in ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }
  
  throw lastError || new Error('Operation failed after retries');
}

async function createUserProfileIfNeeded(user: any) {
  try {
    const { data: existingUser } = await supabase
      .from('users')
      .select('id')
      .eq('id', user.id)
      .single();

    if (!existingUser) {
      console.log('Creating new user profile');
      const { error } = await supabase.from('users').insert([
        {
          id: user.id,
          email: user.email,
          full_name: user.user_metadata.full_name || user.user_metadata.name || 'משתמש חדש',
          created_at: new Date().toISOString()
        }
      ]);

      if (error) throw error;
      console.log('User profile created successfully');
    }
  } catch (err) {
    console.error('Error handling user profile:', err);
  }
}

// Test connection and log status
async function testConnection() {
  try {
    const { data: { session }, error } = await supabase.auth.getSession();
    
    if (error) {
      console.error('Supabase connection error:', error.message);
      return;
    }
    
    if (session) {
      console.log('Connected to Supabase with active session');
    } else {
      console.log('Connected to Supabase (no active session)');
    }
  } catch (err) {
    console.error('Failed to test Supabase connection:', err);
  }
}

// Initialize connection test
testConnection();