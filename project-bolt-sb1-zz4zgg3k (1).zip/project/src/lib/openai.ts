import OpenAI from 'openai';
import type { BusinessProfile } from '../types';

const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
if (!apiKey) {
  console.error('OpenAI API key is not configured. Please check your .env file.');
}

const openai = new OpenAI({
  apiKey,
  dangerouslyAllowBrowser: true
});

const SYSTEM_PROMPT = `אתה יועץ עסקי מקצועי וחברותי. עליך לפעול לפי ההנחיות הבאות:

1. סגנון תשובה:
   - התחל כל תשובה עם פנייה אישית בשם (אם ידוע)
   - השתמש באימוג'י מתאים בתחילת כל נושא
   - כתוב בצורה ברורה ומסודרת עם כותרות
   - רכז את כל המידע בהודעה אחת ארוכה
   - סיים תמיד עם תוכנית פעולה שבועית

2. מבנה התשובה:
   - פתיחה אישית וחמה
   - 2-3 נקודות עיקריות עם הסבר
   - דוגמאות מעשיות ליישום
   - סיכום קצר
   - תוכנית פעולה שבועית עם 3 צעדים מעשיים

3. תוכן:
   - תן המלצות מעשיות וברורות
   - התייחס לנתונים שסופקו
   - הצע פתרונות ספציפיים
   - הימנע מהכללות

4. תוכנית פעולה שבועית:
   - הוסף כותרת "📌 תוכנית הפעולה שלך לשבוע הקרוב"
   - כלול 3 צעדים מעשיים וברורים
   - השתמש באימוג'י מתאים לכל צעד
   - התבסס על הפרופיל העסקי והאתגרים שצוינו
   - הצע צעדים שניתנים ליישום מיידי`;

export async function getBusinessAdvice(
  profile: BusinessProfile,
  question: string
): Promise<string> {
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4-turbo-preview",
      messages: [
        {
          role: "system",
          content: SYSTEM_PROMPT
        },
        {
          role: "user",
          content: `מידע על העסק:
            שם בעל העסק: ${profile.owner_name}
            שם העסק: ${profile.business_name}
            תחום: ${profile.business_sector}
            שלב: ${profile.business_stage}
            הכנסה חודשית: ${profile.monthly_revenue}
            הוצאות קבועות: ${profile.fixed_expenses}
            הוצאות משתנות: ${profile.variable_expenses}
            אתגרים: ${profile.main_challenges}
            קהל יעד: ${profile.target_customers}
            ערוצי שיווק: ${profile.marketing_channels?.join(', ')}
            תקציב שיווק: ${profile.marketing_budget}
            אתגרי מכירות: ${profile.sales_challenges}

            שאלה: ${question}`
        }
      ],
      temperature: 0.7,
      max_tokens: 2000
    });

    return completion.choices[0]?.message?.content || 'לא הצלחתי לענות על השאלה. נסה לנסח אותה מחדש.';
  } catch (error) {
    console.error('OpenAI API error:', error);
    return 'מצטערים, נתקלנו בבעיה בקבלת הייעוץ. אנא נסה שוב.';
  }
}

export async function getInitialBusinessTips(profile: BusinessProfile): Promise<string[]> {
  if (!apiKey) {
    console.error('OpenAI API key is missing. Returning default tips.');
    return getDefaultTips();
  }

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4-turbo-preview",
      messages: [
        {
          role: "system",
          content: `${SYSTEM_PROMPT}

הערה: התשובה שלך חייבת להיות בפורמט JSON כך:
{
  "tips": [
    "💡 טיפ ראשון עם אימוג'י ופירוט",
    "🎯 טיפ שני עם אימוג'י ופירוט",
    "⭐ טיפ שלישי עם אימוג'י ופירוט"
  ]
}`
        },
        {
          role: "user",
          content: `פרטי העסק:
            שם: ${profile.business_name}
            תחום: ${profile.business_sector}
            קהל יעד: ${profile.target_customers}
            הכנסה חודשית: ${profile.monthly_revenue}
            תקציב שיווק: ${profile.marketing_budget}
            אתגרים: ${profile.main_challenges}
            ערוצי שיווק: ${profile.marketing_channels?.join(', ')}
            יעדים עסקיים: ${profile.business_goals}
            שיטות קידום: ${profile.promotion_methods?.join(', ')}
            אתגרי מכירות: ${profile.sales_challenges}
            הוצאות קבועות: ${profile.fixed_expenses}
            הוצאות משתנות: ${profile.variable_expenses}
            ניהול זמן: ${profile.time_management}
            תחומים לשיפור: ${profile.optimization_needs}`
        }
      ],
      temperature: 0.7,
      max_tokens: 1000,
      response_format: { type: "json_object" }
    });

    const content = completion.choices[0]?.message?.content;
    
    if (!content) {
      console.error('OpenAI API returned empty response');
      return getDefaultTips();
    }

    try {
      const response = JSON.parse(content);
      
      if (!response.tips || !Array.isArray(response.tips) || response.tips.length === 0) {
        console.error('OpenAI API returned invalid tips format:', response);
        return getDefaultTips();
      }
      
      return response.tips;
    } catch (parseError) {
      console.error('Failed to parse OpenAI response:', parseError);
      console.error('Raw response:', content);
      return getDefaultTips();
    }
  } catch (error: any) {
    console.error('OpenAI API error:', error);
    if (error.response) {
      console.error('Error response:', {
        status: error.response.status,
        data: error.response.data
      });
    }
    return getDefaultTips();
  }
}

function getDefaultTips(): string[] {
  return [
    '💡 **התחל בקטן, חשוב בגדול**: זהה את הצעד הקטן ביותר שיכול להביא לשינוי משמעותי בעסק שלך. האם זה שיפור השירות ללקוחות? אולי נוכחות טובה יותר ברשתות החברתיות?',
    
    '🎯 **הכר את הלקוחות שלך**: בנה פרופיל מפורט של הלקוח האידיאלי שלך. מה הצרכים שלו? מה מניע אותו? איפה הוא מחפש פתרונות?',
    
    '⭐ **בנה מותג ייחודי**: מה מייחד אותך מהמתחרים? הדגש את היתרונות הייחודיים שלך בכל נקודת מגע עם הלקוחות.'
  ];
}