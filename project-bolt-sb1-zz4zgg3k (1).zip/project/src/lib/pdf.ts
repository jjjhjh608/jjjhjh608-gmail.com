import { jsPDF } from 'jspdf';
import type { BusinessProfile, ChatMessage } from '../types';
import { format } from 'date-fns';
import { he } from 'date-fns/locale';

export function generateBusinessReport(profile: BusinessProfile, messages: ChatMessage[]) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  // Enable right-to-left text
  doc.setR2L(true);

  // Set font
  doc.setFont('Helvetica');

  // Add title
  doc.setFontSize(24);
  doc.text('דוח יועץ עסקי חכם', 200, 20, { align: 'right' });

  // Add date
  doc.setFontSize(12);
  const today = format(new Date(), 'dd בMMMM yyyy', { locale: he });
  doc.text(today, 200, 30, { align: 'right' });

  // Business Profile Section
  doc.setFontSize(18);
  doc.text('פרטי העסק', 200, 45, { align: 'right' });
  
  doc.setFontSize(12);
  let y = 55;
  const lineHeight = 7;

  // Helper function to add a field with label
  const addField = (label: string, value: any) => {
    if (value) {
      doc.text(`${label}: ${value}`, 200, y, { align: 'right' });
      y += lineHeight;
    }
  };

  addField('שם העסק', profile.business_name);
  addField('תחום', profile.business_sector);
  addField('שלב העסק', profile.business_stage);
  addField('תאריך הקמה', profile.establishment_date);
  addField('מספר עובדים', profile.employees_partners);
  addField('הכנסה חודשית', `₪${profile.monthly_revenue}`);
  addField('תקציב שיווק', profile.marketing_budget);
  addField('קהל יעד', profile.target_customers);
  addField('מיקום לקוחות', profile.customer_location);

  // Add page break if needed
  if (y > 250) {
    doc.addPage();
    y = 20;
  }

  // Advisor's Insights Section
  doc.setFontSize(18);
  doc.text('תובנות והמלצות', 200, y + 10, { align: 'right' });
  y += 20;

  doc.setFontSize(12);
  const assistantMessages = messages.filter(m => m.role === 'assistant');
  
  assistantMessages.forEach(message => {
    const lines = doc.splitTextToSize(message.content, 180);
    
    // Check if we need a new page
    if (y + (lines.length * lineHeight) > 270) {
      doc.addPage();
      y = 20;
    }
    
    doc.text(lines, 200, y, { align: 'right' });
    y += lines.length * lineHeight + 5;
  });

  // Add footer
  doc.setFontSize(10);
  doc.text('דוח זה הופק אוטומטית על ידי מערכת היועץ העסקי החכם', 105, 280, { align: 'center' });

  // Generate filename
  const fileName = `business_advice_${profile.owner_name || 'report'}_${format(new Date(), 'yyyy-MM-dd')}.pdf`;

  return { doc, fileName };
}