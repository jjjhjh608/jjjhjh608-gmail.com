export interface BusinessProfile {
  id: string;
  owner_name?: string;
  business_stage?: 'idea' | 'new' | 'existing';
  business_name?: string;
  business_sector?: string;
  establishment_date?: string;
  employees_partners?: string;
  unique_value?: string;
  target_customers?: string;
  customer_retention?: string;
  customer_location?: string;
  marketing_channels?: string[];
  best_marketing_channel?: string;
  sales_funnel?: string;
  monthly_customers?: number;
  marketing_budget?: string;
  monthly_revenue?: number;
  fixed_expenses?: string;
  variable_expenses?: string;
  is_profitable?: boolean;
  has_debts?: boolean;
  time_management?: string;
  management_tools?: string[];
  optimization_needs?: string;
  main_challenges?: string;
  stuck_areas?: string;
  improvement_attempts?: string;
  age_range?: string;
  gender_focus?: string;
  promotion_methods?: string[];
  sales_challenges?: string;
  income_sources?: string[];
  created_at: string;
  updated_at: string;
}

export interface ChatMessage {
  id: string;
  content: string;
  role: 'assistant' | 'user';
  created_at: string;
}

export interface BusinessReport {
  id: string;
  business_name: string;
  business_type: string;
  target_audience: string;
  monthly_revenue: number;
  marketing_budget: number;
  business_goals: string;
  analysis: {
    strengths: string[];
    weaknesses: string[];
    marketing_channels: string[];
    improvements: string[];
    smart_tips: string[];
  };
  created_at: string;
}

export interface SavedInsight {
  id: string;
  content: string;
  type: 'tip' | 'qa' | 'report';
  created_at: string;
}

export interface DailyTip {
  id: string;
  content: string;
  is_useful: boolean;
  created_at: string;
}