export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          email: string
          full_name: string
          created_at: string
          is_pro: boolean
          last_tip_date: string | null
          last_tip: string | null
        }
        Insert: {
          id?: string
          email: string
          full_name: string
          created_at?: string
          is_pro?: boolean
          last_tip_date?: string | null
          last_tip?: string | null
        }
        Update: {
          id?: string
          email?: string
          full_name?: string
          created_at?: string
          is_pro?: boolean
          last_tip_date?: string | null
          last_tip?: string | null
        }
      }
      business_profiles: {
        Row: {
          id: string
          user_id: string
          business_name: string | null
          business_sector: string | null
          establishment_date: string | null
          employees_partners: string | null
          unique_value: string | null
          target_customers: string | null
          customer_retention: string | null
          customer_location: string | null
          marketing_channels: string[] | null
          best_marketing_channel: string | null
          sales_funnel: string | null
          monthly_customers: number | null
          marketing_budget: string | null
          monthly_revenue: number | null
          fixed_expenses: string | null
          variable_expenses: string | null
          is_profitable: boolean | null
          has_debts: boolean | null
          time_management: string | null
          management_tools: string[] | null
          optimization_needs: string | null
          main_challenges: string | null
          stuck_areas: string | null
          improvement_attempts: string | null
          investment_willingness: string | null
          investment_amount: string | null
          age_range: string | null
          gender_focus: string | null
          promotion_methods: string[] | null
          sales_challenges: string | null
          income_sources: string[] | null
          received_investments: boolean | null
          plan_fundraising: boolean | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          business_name?: string | null
          business_sector?: string | null
          establishment_date?: string | null
          employees_partners?: string | null
          unique_value?: string | null
          target_customers?: string | null
          customer_retention?: string | null
          customer_location?: string | null
          marketing_channels?: string[] | null
          best_marketing_channel?: string | null
          sales_funnel?: string | null
          monthly_customers?: number | null
          marketing_budget?: string | null
          monthly_revenue?: number | null
          fixed_expenses?: string | null
          variable_expenses?: string | null
          is_profitable?: boolean | null
          has_debts?: boolean | null
          time_management?: string | null
          management_tools?: string[] | null
          optimization_needs?: string | null
          main_challenges?: string | null
          stuck_areas?: string | null
          improvement_attempts?: string | null
          investment_willingness?: string | null
          investment_amount?: string | null
          age_range?: string | null
          gender_focus?: string | null
          promotion_methods?: string[] | null
          sales_challenges?: string | null
          income_sources?: string[] | null
          received_investments?: boolean | null
          plan_fundraising?: boolean | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          business_name?: string | null
          business_sector?: string | null
          establishment_date?: string | null
          employees_partners?: string | null
          unique_value?: string | null
          target_customers?: string | null
          customer_retention?: string | null
          customer_location?: string | null
          marketing_channels?: string[] | null
          best_marketing_channel?: string | null
          sales_funnel?: string | null
          monthly_customers?: number | null
          marketing_budget?: string | null
          monthly_revenue?: number | null
          fixed_expenses?: string | null
          variable_expenses?: string | null
          is_profitable?: boolean | null
          has_debts?: boolean | null
          time_management?: string | null
          management_tools?: string[] | null
          optimization_needs?: string | null
          main_challenges?: string | null
          stuck_areas?: string | null
          improvement_attempts?: string | null
          investment_willingness?: string | null
          investment_amount?: string | null
          age_range?: string | null
          gender_focus?: string | null
          promotion_methods?: string[] | null
          sales_challenges?: string | null
          income_sources?: string[] | null
          received_investments?: boolean | null
          plan_fundraising?: boolean | null
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}