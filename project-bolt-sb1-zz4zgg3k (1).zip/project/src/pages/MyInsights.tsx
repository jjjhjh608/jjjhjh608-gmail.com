import React, { useState } from 'react';
import { Download, Mail, Search } from 'lucide-react';
import { useAppStore } from '../store';

export function MyInsights() {
  const [searchTerm, setSearchTerm] = useState('');
  const { savedInsights } = useAppStore();

  const filteredInsights = savedInsights.filter((insight) =>
    insight.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleExportPDF = () => {
    // TODO: Implement PDF export
    console.log('Exporting to PDF...');
  };

  const handleEmailExport = () => {
    // TODO: Implement email export
    console.log('Exporting to email...');
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white p-8 rounded-lg shadow-md">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">התובנות שלי</h1>
          <div className="flex space-x-4">
            <button
              onClick={handleExportPDF}
              className="flex items-center text-blue-600 hover:text-blue-700"
            >
              <Download className="h-5 w-5 ml-1" />
              <span>ייצא ל-PDF</span>
            </button>
            <button
              onClick={handleEmailExport}
              className="flex items-center text-blue-600 hover:text-blue-700"
            >
              <Mail className="h-5 w-5 ml-1" />
              <span>שלח במייל</span>
            </button>
          </div>
        </div>

        <div className="relative mb-6">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="חפש תובנות..."
            className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-md"
          />
          <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
        </div>

        <div className="space-y-4">
          {filteredInsights.map((insight) => (
            <details
              key={insight.id}
              className="border border-gray-200 rounded-lg"
            >
              <summary className="p-4 cursor-pointer hover:bg-gray-50">
                <div className="flex justify-between items-center">
                  <span className="font-medium">
                    {insight.content.substring(0, 100)}...
                  </span>
                  <span className="text-sm text-gray-500">
                    {new Date(insight.created_at).toLocaleDateString()}
                  </span>
                </div>
              </summary>
              <div className="p-4 border-t border-gray-200">
                <p>{insight.content}</p>
              </div>
            </details>
          ))}
        </div>
      </div>
    </div>
  );
}