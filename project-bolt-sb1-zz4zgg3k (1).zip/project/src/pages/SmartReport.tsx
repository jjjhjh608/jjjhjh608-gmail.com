import React, { useState } from 'react';
import { FileText, Download } from 'lucide-react';
import { useAppStore } from '../store';
import type { BusinessReport } from '../types';

const BUSINESS_TYPES = [
  'מסעדה',
  'חנות',
  'עסק מקוון',
  'שירותים מקצועיים',
  'ייעוץ',
  'אחר'
];

export function SmartReport() {
  const [formData, setFormData] = useState({
    businessName: '',
    businessType: '',
    targetAudience: '',
    monthlyRevenue: '',
    marketingBudget: '',
    businessGoals: ''
  });

  const [report, setReport] = useState<BusinessReport | null>(null);
  const addReport = useAppStore((state) => state.addReport);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement OpenAI integration
    const mockReport: BusinessReport = {
      id: Date.now().toString(),
      user_id: '1',
      business_name: formData.businessName,
      business_type: formData.businessType,
      target_audience: formData.targetAudience,
      monthly_revenue: Number(formData.monthlyRevenue),
      marketing_budget: Number(formData.marketingBudget),
      business_goals: formData.businessGoals,
      analysis: {
        strengths: ['יתרון תחרותי חזק', 'מיקום מצוין'],
        weaknesses: ['נוכחות דיגיטלית חלשה'],
        marketing_channels: ['רשתות חברתיות', 'שיווק במייל'],
        improvements: ['שיפור נוכחות ברשת', 'הגדלת מאמצי שיווק'],
        smart_tips: [
          'השקע בפרסום ממומן',
          'צור תוכן איכותי',
          'בנה מאגר לקוחות'
        ]
      },
      created_at: new Date().toISOString()
    };

    setReport(mockReport);
    addReport(mockReport);
  };

  const handleExportPDF = () => {
    // TODO: Implement PDF export
    console.log('Exporting to PDF...');
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white p-8 rounded-lg shadow-md">
        <h1 className="text-2xl font-bold mb-6">דוח עסקי חכם</h1>
        
        {!report ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                שם העסק
              </label>
              <input
                type="text"
                value={formData.businessName}
                onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                סוג העסק
              </label>
              <select
                value={formData.businessType}
                onChange={(e) => setFormData({ ...formData, businessType: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                required
              >
                <option value="">בחר סוג עסק</option>
                {BUSINESS_TYPES.map((type) => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                קהל יעד
              </label>
              <input
                type="text"
                value={formData.targetAudience}
                onChange={(e) => setFormData({ ...formData, targetAudience: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                הכנסה חודשית (₪)
              </label>
              <input
                type="number"
                value={formData.monthlyRevenue}
                onChange={(e) => setFormData({ ...formData, monthlyRevenue: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                תקציב שיווק חודשי (₪)
              </label>
              <input
                type="number"
                value={formData.marketingBudget}
                onChange={(e) => setFormData({ ...formData, marketingBudget: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                יעדים עסקיים
              </label>
              <textarea
                value={formData.businessGoals}
                onChange={(e) => setFormData({ ...formData, businessGoals: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                rows={4}
                required
              />
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
            >
              צור דוח
            </button>
          </form>
        ) : (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">
                דוח עבור: {report.business_name}
              </h2>
              <button
                onClick={handleExportPDF}
                className="flex items-center text-blue-600 hover:text-blue-700"
              >
                <Download className="h-5 w-5 ml-1" />
                <span>ייצא ל-PDF</span>
              </button>
            </div>

            <div className="space-y-4">
              <section>
                <h3 className="text-lg font-semibold mb-2">💪 חוזקות</h3>
                <ul className="list-disc list-inside space-y-1">
                  {report.analysis.strengths.map((strength, index) => (
                    <li key={index}>{strength}</li>
                  ))}
                </ul>
              </section>

              <section>
                <h3 className="text-lg font-semibold mb-2">🎯 נקודות לשיפור</h3>
                <ul className="list-disc list-inside space-y-1">
                  {report.analysis.weaknesses.map((weakness, index) => (
                    <li key={index}>{weakness}</li>
                  ))}
                </ul>
              </section>

              <section>
                <h3 className="text-lg font-semibold mb-2">📢 ערוצי שיווק מומלצים</h3>
                <ul className="list-disc list-inside space-y-1">
                  {report.analysis.marketing_channels.map((channel, index) => (
                    <li key={index}>{channel}</li>
                  ))}
                </ul>
              </section>

              <section>
                <h3 className="text-lg font-semibold mb-2">💡 טיפים חכמים</h3>
                <ul className="list-disc list-inside space-y-1">
                  {report.analysis.smart_tips.map((tip, index) => (
                    <li key={index}>{tip}</li>
                  ))}
                </ul>
              </section>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}