import React from 'react';
import { Check } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAppStore } from '../store';

export function Pricing() {
  const navigate = useNavigate();
  const { user, setUser } = useAppStore();

  const handleUpgrade = () => {
    // TODO: Implement payment integration
    setUser(user ? { ...user, is_pro: true } : null);
    navigate('/dashboard');
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-center mb-8">תכניות מחיר</h1>
      
      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-lg shadow-md">
          <h2 className="text-2xl font-bold mb-4">חינם</h2>
          <p className="text-gray-600 mb-6">התחל את המסע שלך</p>
          <div className="space-y-4 mb-8">
            <div className="flex items-center">
              <Check className="h-5 w-5 text-green-500 ml-2" />
              <span>דוח עסקי בסיסי</span>
            </div>
            <div className="flex items-center">
              <Check className="h-5 w-5 text-green-500 ml-2" />
              <span>5 שאלות ליועץ החכם בחודש</span>
            </div>
            <div className="flex items-center">
              <Check className="h-5 w-5 text-green-500 ml-2" />
              <span>טיפ יומי</span>
            </div>
          </div>
          <p className="text-2xl font-bold mb-6">₪0 / חודש</p>
          <button
            className="w-full py-2 px-4 border-2 border-blue-600 text-blue-600 rounded-lg hover:bg-blue-50 transition-colors"
          >
            התחל עכשיו
          </button>
        </div>

        <div className="bg-white p-8 rounded-lg shadow-md border-2 border-blue-600">
          <div className="absolute top-4 left-4 bg-blue-600 text-white px-3 py-1 rounded-full text-sm">
            מומלץ
          </div>
          <h2 className="text-2xl font-bold mb-4">PRO</h2>
          <p className="text-gray-600 mb-6">קח את העסק שלך לשלב הבא</p>
          <div className="space-y-4 mb-8">
            <div className="flex items-center">
              <Check className="h-5 w-5 text-green-500 ml-2" />
              <span>דוחות עסקיים ללא הגבלה</span>
            </div>
            <div className="flex items-center">
              <Check className="h-5 w-5 text-green-500 ml-2" />
              <span>שאלות ללא הגבלה</span>
            </div>
            <div className="flex items-center">
              <Check className="h-5 w-5 text-green-500 ml-2" />
              <span>ייעוץ עסקי שבועי פרימיום</span>
            </div>
            <div className="flex items-center">
              <Check className="h-5 w-5 text-green-500 ml-2" />
              <span>ייצוא לPDF</span>
            </div>
            <div className="flex items-center">
              <Check className="h-5 w-5 text-green-500 ml-2" />
              <span>תמיכה מועדפת</span>
            </div>
          </div>
          <p className="text-2xl font-bold mb-6">₪99 / חודש</p>
          <button
            onClick={handleUpgrade}
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
          >
            שדרג עכשיו
          </button>
        </div>
      </div>
    </div>
  );
}