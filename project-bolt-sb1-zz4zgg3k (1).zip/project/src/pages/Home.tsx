import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppStore } from '../store';
import { Brain, ArrowLeft, Clock, Target, FileText, Sparkles, CheckCircle, Zap, Users } from 'lucide-react';
import { motion } from 'framer-motion';
import { ImageCarousel } from '../components/ImageCarousel';

const benefits = [
  {
    icon: Zap,
    title: 'מענה מיידי',
    description: 'קבל תשובות ותובנות תוך שניות, בלי המתנה ליועץ אנושי'
  },
  {
    icon: Target,
    title: 'ייעוץ מותאם אישית',
    description: 'המלצות מדויקות המבוססות על הנתונים והאתגרים הייחודיים של העסק שלך'
  },
  {
    icon: CheckCircle,
    title: 'תוכנית פעולה חכמה',
    description: 'קבל צעדים מעשיים וברורים שתוכל ליישם כבר היום כדי לקדם את העסק'
  }
];

const steps = [
  {
    number: '01',
    icon: Users,
    title: 'מילוי פרופיל עסקי',
    description: 'ענה על מספר שאלות קצרות על העסק שלך',
    color: 'from-blue-500 to-blue-600'
  },
  {
    number: '02',
    icon: Brain,
    title: 'ניתוח חכם',
    description: 'המערכת מנתחת את המידע ומזהה הזדמנויות',
    color: 'from-purple-500 to-purple-600'
  },
  {
    number: '03',
    icon: Target,
    title: 'קבלת המלצות',
    description: 'קבל תובנות והמלצות מותאמות אישית',
    color: 'from-green-500 to-green-600'
  },
  {
    number: '04',
    icon: FileText,
    title: 'דוח מפורט',
    description: 'קבל דוח PDF מסכם עם כל התובנות וההמלצות',
    color: 'from-orange-500 to-orange-600'
  }
];

export function Home() {
  const navigate = useNavigate();
  const setBusinessProfile = useAppStore((state) => state.setBusinessProfile);

  const handleGetStarted = () => {
    setBusinessProfile({
      id: crypto.randomUUID(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    });
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gray-50 py-20 sm:py-32">
        {/* Abstract background shapes */}
        <div className="absolute inset-0 pointer-events-none">
          <svg className="absolute left-0 top-0 h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path
              d="M0,0 C40,20 60,0 100,10 L100,100 L0,100 Z"
              fill="url(#gradient-1)"
              fillOpacity="0.05"
            />
            <path
              d="M0,20 C30,40 70,30 100,40 L100,100 L0,100 Z"
              fill="url(#gradient-2)"
              fillOpacity="0.05"
            />
            <defs>
              <linearGradient id="gradient-1" gradientTransform="rotate(45)">
                <stop offset="0%" stopColor="#4F46E5" />
                <stop offset="100%" stopColor="#7C3AED" />
              </linearGradient>
              <linearGradient id="gradient-2" gradientTransform="rotate(-45)">
                <stop offset="0%" stopColor="#3B82F6" />
                <stop offset="100%" stopColor="#8B5CF6" />
              </linearGradient>
            </defs>
          </svg>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Content */}
            <div className="text-center lg:text-right order-2 lg:order-1">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
                  היועץ החכם לעסקים
                  <br />
                  <span className="text-3xl sm:text-4xl lg:text-5xl text-gray-600">
                    קבל ייעוץ עסקי מותאם אישית
                  </span>
                </h1>
                
                <p className="text-xl text-gray-600 mb-8 max-w-xl mx-auto lg:mx-0 leading-relaxed">
                  קבל תובנות חכמות והמלצות מעשיות שיעזרו לך להצעיד את העסק קדימה
                </p>

                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleGetStarted}
                  className="inline-flex items-center px-8 py-4 text-lg font-medium bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full shadow-lg hover:shadow-xl transform transition-all duration-200"
                >
                  התחל עכשיו – קבל ייעוץ חינם
                  <ArrowLeft className="mr-2 h-5 w-5" />
                </motion.button>
              </motion.div>
            </div>

            {/* Image Carousel */}
            <div className="order-1 lg:order-2">
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8 }}
              >
                <ImageCarousel />
              </motion.div>
            </div>
          </div>
        </div>
      </div>

      {/* Benefits Section */}
      <div className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-4 leading-tight">
              למה לבחור ביועץ החכם?
            </h2>
            <p className="text-xl text-gray-600 leading-relaxed">
              קבל ייעוץ מקצועי ומותאם אישית בדיוק ברגע שאתה צריך
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <motion.div
                  key={benefit.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.2 }}
                  whileHover={{ y: -5 }}
                  className="bg-white rounded-2xl p-8 shadow-soft-xl hover:shadow-soft-2xl transition-all duration-300"
                >
                  <div className="flex justify-center mb-8">
                    <div className="relative">
                      <div className="absolute inset-0 bg-gradient-to-br from-blue-100 to-purple-100 rounded-full blur-xl opacity-50"></div>
                      <div className="relative bg-gradient-to-br from-blue-500 to-purple-500 p-4 rounded-full">
                        <Icon className="h-8 w-8 text-white" />
                      </div>
                    </div>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4 text-center leading-tight">
                    {benefit.title}
                  </h3>
                  <p className="text-lg text-gray-600 text-center leading-relaxed px-4">
                    {benefit.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>

      {/* How It Works Section */}
      <div className="py-24 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-4 leading-tight">
              איך זה עובד?
            </h2>
            <p className="text-xl text-gray-600 leading-relaxed">
              תהליך פשוט בארבעה שלבים שיעזור לך להצליח
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <motion.div
                  key={step.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.2 }}
                  className="relative"
                >
                  {index < steps.length - 1 && (
                    <div className="hidden lg:block absolute top-1/2 left-1/2 w-full border-t-2 border-dashed border-gray-200 -translate-y-1/2" />
                  )}
                  <div className="bg-white rounded-2xl p-8 shadow-soft-xl relative">
                    <div className="absolute -top-4 -right-4 w-12 h-12 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center text-white font-bold">
                      {step.number}
                    </div>
                    <div className="flex justify-center mb-8">
                      <div className="relative">
                        <div className="absolute inset-0 bg-gradient-to-br from-blue-100 to-purple-100 rounded-full blur-xl opacity-50"></div>
                        <div className={`relative bg-gradient-to-br ${step.color} p-4 rounded-full`}>
                          <Icon className="h-8 w-8 text-white" />
                        </div>
                      </div>
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-4 text-center leading-tight">
                      {step.title}
                    </h3>
                    <p className="text-base text-gray-600 text-center leading-relaxed px-4">
                      {step.description}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-24 bg-gradient-to-br from-gray-900 to-blue-900 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20 blur-3xl"></div>
            <div className="relative">
              <h2 className="text-4xl sm:text-5xl font-bold mb-6 leading-tight">
                מוכן לקחת את העסק שלך לשלב הבא?
              </h2>
              <p className="text-xl mb-8 text-gray-300 leading-relaxed">
                קבל ייעוץ מקצועי מותאם אישית לעסק שלך
              </p>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleGetStarted}
                className="inline-flex items-center px-8 py-4 text-lg font-medium bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 rounded-full shadow-lg hover:shadow-xl transform transition-all duration-200"
              >
                כן, אני רוצה להתחיל עכשיו
                <ArrowLeft className="mr-2 h-5 w-5" />
              </motion.button>
              <p className="mt-4 text-sm text-gray-400">
                בלי התחייבות, בחינם, תוך פחות מ־3 דקות
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}