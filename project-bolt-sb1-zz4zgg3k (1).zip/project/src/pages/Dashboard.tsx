import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAppStore } from '../store';
import { Building2, Users, Target, LineChart, Wallet, Clock, AlertCircle, HelpCircle, ChevronLeft, ChevronRight, CheckCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { getInitialBusinessTips } from '../lib/openai';
import { LoadingOverlay } from '../components/LoadingOverlay';
import { WelcomeStep } from '../components/WelcomeStep';
import type { BusinessProfile } from '../types';

const STORAGE_KEY = 'business_profile_draft';
const LAST_STEP_KEY = 'business_profile_last_step';

const BUSINESS_SECTORS = [
  'מסעדנות',
  'קמעונאות',
  'שירותים מקצועיים',
  'טכנולוגיה',
  'חינוך',
  'בריאות',
  'בנייה',
  'אחר'
];

const MARKETING_CHANNELS = [
  'פייסבוק',
  'אינסטגרם',
  'גוגל',
  'אתר אינטרנט',
  'וואטסאפ עסקי',
  'המלצות',
  'אחר'
];

const FormField = React.memo(({ 
  label, 
  children, 
  tooltip 
}: { 
  label: string;
  children: React.ReactNode;
  tooltip?: string;
}) => (
  <div className="relative space-y-2">
    <div className="flex items-center">
      <label className="block text-lg font-medium text-gray-700">
        {label}
      </label>
      {tooltip && (
        <div className="group relative mr-2">
          <HelpCircle className="h-4 w-4 text-gray-400" />
          <div className="absolute right-0 w-64 p-2 bg-white rounded-lg shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-10">
            <p className="text-sm text-gray-600">{tooltip}</p>
          </div>
        </div>
      )}
    </div>
    {children}
  </div>
));

FormField.displayName = 'FormField';

export function Dashboard() {
  const navigate = useNavigate();
  const location = useLocation();
  const { businessProfile, setBusinessProfile, addChatMessage, clearChatMessages } = useAppStore();
  const [showWelcome, setShowWelcome] = useState(!businessProfile?.owner_name);
  const [currentStep, setCurrentStep] = useState(() => {
    const savedStep = localStorage.getItem(LAST_STEP_KEY);
    return savedStep ? parseInt(savedStep, 10) : 1;
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showError, setShowError] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [formData, setFormData] = useState<Partial<BusinessProfile>>(() => {
    const savedData = localStorage.getItem(STORAGE_KEY);
    if (savedData) {
      try {
        return JSON.parse(savedData);
      } catch (e) {
        console.error('Error parsing saved form data:', e);
      }
    }
    return businessProfile || {
      business_name: '',
      business_sector: '',
      establishment_date: '',
      employees_partners: '',
      unique_value: '',
      target_customers: '',
      customer_retention: '',
      customer_location: '',
      marketing_channels: [],
      best_marketing_channel: '',
      sales_funnel: '',
      monthly_customers: 0,
      marketing_budget: '',
      monthly_revenue: 0,
      fixed_expenses: '',
      variable_expenses: '',
      is_profitable: false,
      has_debts: false,
      time_management: '',
      management_tools: [],
      optimization_needs: '',
      main_challenges: '',
      stuck_areas: '',
      improvement_attempts: '',
      age_range: '',
      gender_focus: '',
      promotion_methods: [],
      sales_challenges: '',
      income_sources: []
    };
  });

  const isEditMode = location.search.includes('edit=true');

  // Auto-save effect
  useEffect(() => {
    const saveFormData = () => {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(formData));
      localStorage.setItem(LAST_STEP_KEY, currentStep.toString());
    };

    // Save immediately when data changes
    saveFormData();

    // Also save when user leaves/refreshes page
    window.addEventListener('beforeunload', saveFormData);
    return () => window.removeEventListener('beforeunload', saveFormData);
  }, [formData, currentStep]);

  // Success message timeout
  useEffect(() => {
    if (showSuccess) {
      const timer = setTimeout(() => {
        setShowSuccess(false);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [showSuccess]);

  const handleWelcomeComplete = (name: string, stage: 'idea' | 'new' | 'existing') => {
    setFormData(prev => ({
      ...prev,
      owner_name: name,
      business_stage: stage
    }));
    setShowWelcome(false);
  };

  useEffect(() => {
    setShowError(false);
    setError('');
  }, [currentStep]);

  const handleInputChange = (field: keyof BusinessProfile, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value
    }));
    if (error) {
      setError('');
      setShowError(false);
    }
  };

  const clearSavedData = () => {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(LAST_STEP_KEY);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1);
      return;
    }

    setIsSubmitting(true);
    setError('');
    setShowError(false);
    setLoading(true);

    try {
      const profile = {
        id: formData.id || crypto.randomUUID(),
        ...formData,
        created_at: formData.created_at || new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      clearChatMessages();
      setBusinessProfile(profile);
      clearSavedData();

      if (isEditMode) {
        setShowSuccess(true);
        navigate('/dashboard');
      } else {
        try {
          const tips = await getInitialBusinessTips(profile);
          
          tips.forEach(tip => {
            addChatMessage({
              id: crypto.randomUUID(),
              content: tip,
              role: 'assistant',
              created_at: new Date().toISOString()
            });
          });
        } catch (aiError) {
          console.error('Error getting AI tips:', aiError);
        }

        navigate('/ask-advisor');
      }
    } catch (err) {
      console.error('Error saving business profile:', err);
      setError('שגיאה בשמירת הפרופיל העסקי. אנא נסה שוב.');
      setShowError(true);
      setLoading(false);
    }
  };

  const textareaClassName = "w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all duration-200 min-h-[120px] resize-none overflow-y-auto text-base leading-relaxed";
  const inputClassName = "w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all duration-200";

  const steps = [
    { id: 1, title: 'מידע כללי על העסק', icon: Building2 },
    { id: 2, title: 'קהל יעד', icon: Target },
    { id: 3, title: 'שיווק ומכירות', icon: LineChart },
    { id: 4, title: 'נתונים פיננסיים', icon: Wallet },
    { id: 5, title: 'תפעול וניהול', icon: Clock },
    { id: 6, title: 'אתגרים', icon: AlertCircle }
  ];

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <FormField 
              label="שם העסק"
              tooltip="השם הרשמי של העסק שלך"
            >
              <input
                type="text"
                value={formData.business_name || ''}
                onChange={(e) => handleInputChange('business_name', e.target.value)}
                placeholder="לדוגמה: סטודיו דני לעיצוב"
                className={inputClassName}
              />
            </FormField>

            <FormField 
              label="תחום הפעילות"
              tooltip="הענף העסקי בו אתה פועל"
            >
              <select
                value={formData.business_sector || ''}
                onChange={(e) => handleInputChange('business_sector', e.target.value)}
                className={inputClassName}
              >
                <option value="">בחר תחום</option>
                {BUSINESS_SECTORS.map((sector) => (
                  <option key={sector} value={sector}>{sector}</option>
                ))}
              </select>
            </FormField>

            <FormField 
              label="תאריך הקמת העסק"
              tooltip="מתי התחלת את הפעילות העסקית"
            >
              <input
                type="date"
                value={formData.establishment_date || ''}
                onChange={(e) => handleInputChange('establishment_date', e.target.value)}
                className={inputClassName}
              />
            </FormField>

            <FormField 
              label="מה מייחד את העסק שלך?"
              tooltip="מה היתרון התחרותי שלך בשוק"
            >
              <textarea
                value={formData.unique_value || ''}
                onChange={(e) => handleInputChange('unique_value', e.target.value)}
                placeholder="לדוגמה: עיצוב מותאם אישית עם מומחיות בעיצוב לוגו לעסקים קטנים"
                className={textareaClassName}
              />
            </FormField>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <FormField 
              label="טווח גילאים"
              tooltip="טווח הגילאים של קהל היעד שלך"
            >
              <select
                value={formData.age_range || ''}
                onChange={(e) => handleInputChange('age_range', e.target.value)}
                className={inputClassName}
              >
                <option value="">בחר טווח גילאים</option>
                <option value="18-24">18-24</option>
                <option value="25-34">25-34</option>
                <option value="35-44">35-44</option>
                <option value="45-54">45-54</option>
                <option value="55+">55+</option>
                <option value="all">כל הגילאים</option>
              </select>
            </FormField>

            <FormField 
              label="מגדר"
              tooltip="המגדר העיקרי של קהל היעד"
            >
              <select
                value={formData.gender_focus || ''}
                onChange={(e) => handleInputChange('gender_focus', e.target.value)}
                className={inputClassName}
              >
                <option value="">בחר מגדר</option>
                <option value="נשים">נשים</option>
                <option value="גברים">גברים</option>
                <option value="all">כולם</option>
              </select>
            </FormField>

            <FormField 
              label="היכן נמצאים הלקוחות שלך?"
              tooltip="האזורים הגיאוגרפיים בהם נמצאים לקוחותיך"
            >
              <input
                type="text"
                value={formData.customer_location || ''}
                onChange={(e) => handleInputChange('customer_location', e.target.value)}
                placeholder="לדוגמה: תל אביב והסביבה"
                className={inputClassName}
              />
            </FormField>

            <FormField 
              label="תאר את הלקוח האידיאלי שלך"
              tooltip="מאפיינים של הלקוח האידיאלי"
            >
              <textarea
                value={formData.target_customers || ''}
                onChange={(e) => handleInputChange('target_customers', e.target.value)}
                placeholder="לדוגמה: עסקים קטנים שזקוקים לעיצוב לוגו מקצועי ומיתוג"
                className={textareaClassName}
              />
            </FormField>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <FormField 
              label="איך אתה מקדם את העסק כיום?"
              tooltip="שיטות הקידום הנוכחיות"
            >
              <div className="grid grid-cols-2 gap-4">
                {MARKETING_CHANNELS.map((channel) => (
                  <label key={channel} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={formData.promotion_methods?.includes(channel) || false}
                      onChange={(e) => {
                        const methods = formData.promotion_methods || [];
                        if (e.target.checked) {
                          handleInputChange('promotion_methods', [...methods, channel]);
                        } else {
                          handleInputChange(
                            'promotion_methods',
                            methods.filter(m => m !== channel)
                          );
                        }
                      }}
                      className="w-5 h-5 text-primary-600 border-2 border-gray-300 rounded-md focus:ring-primary-500"
                    />
                    <span className="mr-2">{channel}</span>
                  </label>
                ))}
              </div>
            </FormField>

            <FormField 
              label="תקציב שיווק חודשי"
              tooltip="כמה אתה משקיע בשיווק בחודש"
            >
              <input
                type="number"
                value={formData.marketing_budget || ''}
                onChange={(e) => handleInputChange('marketing_budget', e.target.value)}
                placeholder="לדוגמה: 2000"
                className={inputClassName}
              />
            </FormField>

            <FormField 
              label="אתגרים במכירות"
              tooltip="תאר את האתגרים העיקריים במכירות"
            >
              <textarea
                value={formData.sales_challenges || ''}
                onChange={(e) => handleInputChange('sales_challenges', e.target.value)}
                placeholder="לדוגמה: קושי בהשגת לקוחות חדשים, תחרות גבוהה על המחיר"
                className={textareaClassName}
              />
            </FormField>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <FormField 
              label="הכנסה חודשית ממוצעת"
              tooltip="ההכנסה הממוצעת של העסק בחודש"
            >
              <input
                type="number"
                value={formData.monthly_revenue || ''}
                onChange={(e) => handleInputChange('monthly_revenue', Number(e.target.value))}
                placeholder="לדוגמה: 15000"
                className={inputClassName}
              />
            </FormField>

            <FormField 
              label="הוצאות קבועות"
              tooltip="הוצאות שחוזרות על עצמן כל חודש"
            >
              <input
                type="text"
                value={formData.fixed_expenses || ''}
                onChange={(e) => handleInputChange('fixed_expenses', e.target.value)}
                placeholder="לדוגמה: שכירות 3000, ביטוח 500"
                className={inputClassName}
              />
            </FormField>

            <FormField 
              label="הוצאות משתנות"
              tooltip="הוצאות שמשתנות בהתאם להיקף הפעילות"
            >
              <input
                type="text"
                value={formData.variable_expenses || ''}
                onChange={(e) => handleInputChange('variable_expenses', e.target.value)}
                placeholder="לדוגמה: חומרי גלם, עמלות מכירה"
                className={inputClassName}
              />
            </FormField>

            <FormField 
              label="מקורות הכנסה"
              tooltip="מהם מקורות ההכנסה העיקריים של העסק"
            >
              <div className="grid grid-cols-2 gap-4">
                {['מכירת מוצרים', 'שירותים', 'מנויים', 'עמלות', 'אחר'].map((source) => (
                  <label key={source} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={formData.income_sources?.includes(source) || false}
                      onChange={(e) => {
                        const sources = formData.income_sources || [];
                        if (e.target.checked) {
                          handleInputChange('income_sources', [...sources, source]);
                        } else {
                          handleInputChange(
                            'income_sources',
                            sources.filter(s => s !== source)
                          );
                        }
                      }}
                      className="w-5 h-5 text-primary-600 border-2 border-gray-300 rounded-md focus:ring-primary-500"
                    />
                    <span className="mr-2">{source}</span>
                  </label>
                ))}
              </div>
            </FormField>
          </div>
        );

      case 5:
        return (
          <div className="space-y-6">
            <FormField 
              label="מספר עובדים"
              tooltip="כמה עובדים יש בעסק"
            >
              <input
                type="number"
                value={formData.employees_partners || ''}
                onChange={(e) => handleInputChange('employees_partners', e.target.value)}
                placeholder="לדוגמה: 3"
                className={inputClassName}
              />
            </FormField>

            <FormField 
              label="איך אתה מנהל את הזמן בעסק?"
              tooltip="תאר את שגרת היום שלך בעסק"
            >
              <textarea
                value={formData.time_management || ''}
                onChange={(e) => handleInputChange('time_management', e.target.value)}
                placeholder="לדוגמה: 4 שעות עבודה מול לקוחות, 2 שעות ניהול, 2 שעות שיווק"
                className={textareaClassName}
              />
            </FormField>

            <FormField 
              label="אילו תהליכים דורשים שיפור?"
              tooltip="תהליכים שאתה מרגיש שאפשר לייעל"
            >
              <textarea
                value={formData.optimization_needs || ''}
                onChange={(e) => handleInputChange('optimization_needs', e.target.value)}
                placeholder="לדוגמה: ניהול זמן טוב יותר, אוטומציה של תהליכי עבודה"
                className={textareaClassName}
              />
            </FormField>
          </div>
        );

      case 6:
        return (
          <div className="space-y-6">
            <FormField 
              label="מהם האתגרים המרכזיים שלך?"
              tooltip="האתגרים העיקריים איתם אתה מתמודד"
            >
              <textarea
                value={formData.main_challenges || ''}
                onChange={(e) => handleInputChange('main_challenges', e.target.value)}
                placeholder="לדוגמה: קושי בהשגת לקוחות חדשים, תחרות גבוהה בשוק"
                className={textareaClassName}
              />
            </FormField>

            <FormField 
              label="איזה תחום בעסק מרגיש ׳תקוע׳?"
              tooltip="תחומים שאתה מרגיש שלא מתקדמים"
            >
              <textarea
                value={formData.stuck_areas || ''}
                onChange={(e) => handleInputChange('stuck_areas', e.target.value)}
                placeholder="לדוגמה: השיווק ברשתות החברתיות לא מביא תוצאות"
                className={textareaClassName}
              />
            </FormField>

            <FormField 
              label="מה ניסית לעשות כדי להתמודד?"
              tooltip="פתרונות שניסית ליישם"
            >
              <textarea
                value={formData.improvement_attempts || ''}
                onChange={(e) => handleInputChange('improvement_attempts', e.target.value)}
                placeholder="לדוגמה: ניסיתי לפרסם בפייסבוק, להוריד מחירים"
                className={textareaClassName}
              />
            </FormField>
          </div>
        );

      default:
        return null;
    }
  };

  if (showWelcome) {
    return <WelcomeStep onNext={handleWelcomeComplete} />;
  }

  return (
    <div className="w-full px-0 sm:px-4 py-4 sm:py-8">
      {loading && <LoadingOverlay onComplete={() => navigate('/ask-advisor')} />}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-none sm:rounded-3xl shadow-soft-2xl p-4 sm:p-8"
      >
        {showSuccess && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-4 right-4 bg-green-50 text-green-600 px-6 py-3 rounded-lg shadow-lg flex items-center space-x-2 z-50"
          >
            <CheckCircle className="h-5 w-5" />
            <span>הפרופיל העסקי עודכן בהצלחה!</span>
          </motion.div>
        )}

        <div className="mb-8 sm:mb-12 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-2xl sm:text-4xl font-bold text-gray-900 mb-4"
          >
            {isEditMode ? 'עריכת פרופיל עסקי' : 'בואו נכיר את העסק שלך'}
          </motion.h1>
          <p className="text-base sm:text-xl text-gray-600">
            כל שאלה שתמלא/י עוזרת לנו להבין טוב יותר את העסק שלך ולתת לך ייעוץ מדויק יותר.
          </p>
        </div>

        <div className="mb-8 sm:mb-12">
          <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${(currentStep / steps.length) * 100}%` }}
              className="h-full bg-gradient-to-r from-primary-500 to-primary-600 rounded-full"
              transition={{ duration: 0.3 }}
            />
          </div>
          <div className="mt-4 flex justify-between items-center text-sm font-medium">
            <span className="text-primary-600">
              שלב {currentStep} מתוך {steps.length}
            </span>
            <span className="text-gray-500">
              {Math.round((currentStep / steps.length) * 100)}% הושלם
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-3">
            <nav className="space-y-2 lg:sticky lg:top-8">
              {steps.map((step) => {
                const Icon = step.icon;
                return (
                  <motion.button
                    key={step.id}
                    whileHover={{ scale: 1.02 }}
                    onClick={() => setCurrentStep(step.id)}
                    className={`w-full flex items-center px-4 sm:px-6 py-3 sm:py-4 rounded-xl transition-all duration-200 ${
                      currentStep === step.id
                        ? 'bg-primary-50 text-primary-600 shadow-sm'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="h-5 w-5 sm:h-6 sm:w-6 ml-3" />
                    <span className="font-medium text-sm sm:text-base">{step.title}</span>
                  </motion.button>
                );
              })}
            </nav>
          </div>

          <div className="lg:col-span-9">
            <AnimatePresence mode="wait">
              <motion.form
                key={currentStep}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                onSubmit={handleSubmit}
                className="space-y-6 sm:space-y-8"
              >
                {showError && error && (
                  <div className="bg-red-50 text-red-600 p-4 rounded-xl mb-6">
                    {error}
                  </div>
                )}

                {renderStepContent()}

                <div className="flex justify-between items-center mt-8 sm:mt-12">
                  {currentStep > 1 && (
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      type="button"
                      onClick={() => setCurrentStep(currentStep - 1)}
                      className="flex items-center px-4 sm:px-6 py-2 sm:py-3 text-gray-600 hover:text-gray-800 transition-colors"
                    >
                      <ChevronRight className="h-5 w-5 ml-2" />
                      חזור
                    </motion.button>
                  )}
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    type="submit"
                    disabled={isSubmitting}
                    className={`flex items-center px-6 sm:px-8 py-3 sm:py-4 rounded-full text-base sm:text-lg font-medium transition-all duration-200 ${
                      currentStep === steps.length
                        ? 'bg-gradient-to-r from-primary-600 to-primary-500 text-white shadow-lg hover:shadow-xl'
                        : 'bg-primary-600 text-white hover:bg-primary-700'
                    } disabled:opacity-50`}
                  >
                    {isSubmitting ? (
                      'שומר...'
                    ) : (currentStep === steps.length ? (
                      <>
                        <span>{isEditMode ? 'שמור שינויים' : 'סיום'}</span>
                        <ChevronLeft className="h-5 w-5 mr-2" />
                      </>
                    ) : (
                      <>
                        <span>המשך</span>
                        <ChevronLeft className="h-5 w-5 mr-2" />
                      </>
                    ))}
                  </motion.button>
                </div>
              </motion.form>
            </AnimatePresence>
          </div>
        </div>
      </motion.div>
    </div>
  );
}