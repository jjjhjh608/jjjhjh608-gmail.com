import React, { useState, useRef, useEffect } from 'react';
import { Send, Save, RefreshCw, FileEdit, HelpCircle, FileText, X, Bot, User } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppStore } from '../store';
import { getBusinessAdvice } from '../lib/openai';
import { LoadingMessage } from '../components/LoadingMessage';
import { ReportButton } from '../components/ReportButton';
import ReactMarkdown from 'react-markdown';
import { useNavigate } from 'react-router-dom';
import type { ChatMessage, SavedInsight } from '../types';

function formatDate(date: Date): string {
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  
  const isToday = date.toDateString() === today.toDateString();
  const isYesterday = date.toDateString() === yesterday.toDateString();
  
  const timeString = date.toLocaleTimeString('he-IL', { 
    hour: '2-digit', 
    minute: '2-digit' 
  });
  
  if (isToday) {
    return timeString;
  } else if (isYesterday) {
    return `אתמול, ${timeString}`;
  } else {
    return date.toLocaleDateString('he-IL', { 
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  }
}

function shouldShowDate(currentMessage: ChatMessage, previousMessage: ChatMessage | undefined): boolean {
  if (!previousMessage) return true;
  
  const currentDate = new Date(currentMessage.created_at);
  const previousDate = new Date(previousMessage.created_at);
  
  return currentDate.toDateString() !== previousDate.toDateString();
}

export default function AskAdvisor() {
  const [question, setQuestion] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showToolbar, setShowToolbar] = useState(true);
  const { businessProfile, chatMessages, addChatMessage, addSavedInsight, clearChatMessages } = useAppStore();
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatMessages]);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setShowToolbar(false);
      } else {
        setShowToolbar(true);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim() || !businessProfile) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      content: question,
      role: 'user',
      created_at: new Date().toISOString()
    };

    addChatMessage(userMessage);
    setQuestion('');
    setLoading(true);
    setError('');

    try {
      const context = chatMessages.length > 0 
        ? `Based on our previous conversation where we discussed: ${chatMessages
            .filter(m => m.role === 'assistant')
            .map(m => m.content)
            .join(' ')} - Here's a follow-up question: ${question}`
        : question;

      const greeting = businessProfile.owner_name ? `היי ${businessProfile.owner_name}, ` : '';
      const response = await getBusinessAdvice(businessProfile, context);
      
      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        content: greeting + response,
        role: 'assistant',
        created_at: new Date().toISOString()
      };

      addChatMessage(assistantMessage);
    } catch (err) {
      setError('שגיאה בקבלת תשובה מהיועץ החכם. נסה שוב.');
    } finally {
      setLoading(false);
      if (inputRef.current) {
        inputRef.current.focus();
      }
    }
  };

  const handleSaveInsight = async (message: ChatMessage) => {
    const insight: SavedInsight = {
      id: Date.now().toString(),
      content: message.content,
      type: 'qa',
      created_at: new Date().toISOString()
    };

    addSavedInsight(insight);

    const successMessage = document.createElement('div');
    successMessage.className = 'fixed bottom-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
    successMessage.textContent = 'התובנה נשמרה בהצלחה!';
    document.body.appendChild(successMessage);

    setTimeout(() => {
      successMessage.remove();
    }, 3000);
  };

  const handleExportPDF = async (message: ChatMessage) => {
    try {
      const { jsPDF } = await import('jspdf');
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      doc.setR2L(true);
      doc.setFont('Helvetica');

      doc.setFontSize(20);
      doc.text('ייעוץ עסקי חכם', 200, 20, { align: 'right' });

      doc.setFontSize(14);
      if (businessProfile?.business_name) {
        doc.text(`עסק: ${businessProfile.business_name}`, 200, 40, { align: 'right' });
      }
      if (businessProfile?.business_sector) {
        doc.text(`תחום: ${businessProfile.business_sector}`, 200, 50, { align: 'right' });
      }

      const date = new Date().toLocaleDateString('he-IL');
      doc.text(`תאריך: ${date}`, 200, 60, { align: 'right' });

      doc.setFontSize(12);
      const contentLines = doc.splitTextToSize(message.content, 180);
      doc.text(contentLines, 200, 80, { align: 'right' });

      doc.setFontSize(10);
      doc.text('נוצר על ידי היועץ החכם לעסקים', 105, 280, { align: 'center' });

      doc.save('business-advice.pdf');

      const successMessage = document.createElement('div');
      successMessage.className = 'fixed bottom-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
      successMessage.textContent = 'הקובץ נוצר בהצלחה!';
      document.body.appendChild(successMessage);

      setTimeout(() => {
        successMessage.remove();
      }, 3000);
    } catch (error) {
      console.error('Error generating PDF:', error);
      const errorMessage = document.createElement('div');
      errorMessage.className = 'fixed bottom-4 right-4 bg-red-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
      errorMessage.textContent = 'שגיאה ביצירת הקובץ';
      document.body.appendChild(errorMessage);

      setTimeout(() => {
        errorMessage.remove();
      }, 3000);
    }
  };

  const handleStartNewChat = () => {
    clearChatMessages();
  };

  const handleEditProfile = () => {
    navigate('/dashboard?edit=true');
  };

  if (!businessProfile) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="bg-white p-8 rounded-lg shadow-md">
          <h1 className="text-2xl font-bold mb-6">שאל את היועץ החכם</h1>
          <p className="text-gray-600">
            כדי להתחיל את הייעוץ, אנא מלא תחילה את פרטי העסק שלך{' '}
            <a href="/dashboard" className="text-blue-600 hover:text-blue-700">
              בדף הפרופיל העסקי
            </a>
            .
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-blue-50 to-white flex">
      <AnimatePresence>
        {showToolbar && (
          <motion.div
            initial={{ x: -100, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -100, opacity: 0 }}
            className="w-64 bg-white shadow-soft-xl p-4 flex flex-col gap-3 relative"
          >
            <button
              onClick={() => setShowToolbar(false)}
              className="md:hidden absolute top-2 right-2 text-gray-500 hover:text-gray-700"
            >
              <X className="h-5 w-5" />
            </button>

            <div className="text-lg font-semibold mb-4 mt-8 md:mt-0">כלים מהירים</div>
            
            <button
              onClick={handleStartNewChat}
              className="flex items-center gap-2 p-3 text-gray-700 hover:bg-blue-50 rounded-lg transition-colors"
            >
              <RefreshCw className="h-5 w-5 text-blue-600" />
              <span>התחל צ'אט חדש</span>
            </button>

            <button
              onClick={handleEditProfile}
              className="flex items-center gap-2 p-3 text-gray-700 hover:bg-blue-50 rounded-lg transition-colors"
            >
              <FileEdit className="h-5 w-5 text-blue-600" />
              <span>ערוך פרופיל עסקי</span>
            </button>

            <ReportButton profile={businessProfile} messages={chatMessages} />

            <button
              onClick={() => {/* TODO: Implement */}}
              className="flex items-center gap-2 p-3 text-gray-700 hover:bg-blue-50 rounded-lg transition-colors"
            >
              <HelpCircle className="h-5 w-5 text-blue-600" />
              <span>שאל שאלה אחרת</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex-1 flex flex-col h-full max-w-5xl mx-auto w-full">
        <div className="p-4 bg-white shadow-md flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">היועץ החכם שלך</h1>
            <p className="text-sm text-gray-600">מנתח את העסק שלך ומציע פתרונות מותאמים אישית</p>
          </div>
          <button
            onClick={() => setShowToolbar(!showToolbar)}
            className="md:hidden p-2 text-gray-600 hover:text-gray-800"
          >
            <HelpCircle className="h-6 w-6" />
          </button>
        </div>

        <div 
          ref={chatContainerRef}
          className="flex-1 overflow-y-auto p-4 space-y-6"
          style={{
            backgroundImage: 'url("data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cg fill=\'%239C92AC\' fill-opacity=\'0.05\'%3E%3Cpath d=\'M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")'
          }}
        >
          {chatMessages.map((message, index) => {
            const prevMessage = index > 0 ? chatMessages[index - 1] : undefined;
            const showDateDivider = shouldShowDate(message, prevMessage);
            const messageDate = new Date(message.created_at);

            return (
              <React.Fragment key={message.id}>
                {showDateDivider && (
                  <div className="flex justify-center my-4">
                    <div className="bg-gray-100 px-4 py-2 rounded-full text-sm text-gray-600">
                      {formatDate(messageDate)}
                    </div>
                  </div>
                )}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${
                    message.role === 'user' ? 'justify-end' : 'justify-start'
                  }`}
                >
                  <div
                    className={`max-w-[85%] p-6 rounded-2xl shadow-soft relative ${
                      message.role === 'user'
                        ? 'bg-gradient-to-br from-blue-600 to-blue-700 text-white'
                        : 'bg-white border border-gray-100'
                    }`}
                  >
                    <div className="flex items-start gap-4">
                      <div className={`flex-shrink-0 ${message.role === 'user' ? 'order-2' : 'order-1'}`}>
                        {message.role === 'user' ? (
                          <User className="h-6 w-6 text-white" />
                        ) : (
                          <Bot className="h-6 w-6 text-blue-600" />
                        )}
                      </div>
                      <div className={`flex-1 ${message.role === 'user' ? 'order-1' : 'order-2'}`}>
                        <div className={`text-lg leading-relaxed ${
                          message.role === 'user' ? 'text-white' : 'text-gray-800'
                        }`}>
                          <ReactMarkdown 
                            className={`prose prose-lg ${
                              message.role === 'user' 
                                ? 'prose-invert' 
                                : 'prose-blue'
                            } max-w-none`}
                          >
                            {message.content}
                          </ReactMarkdown>
                        </div>

                        <div className={`text-sm mt-2 ${
                          message.role === 'user' ? 'text-blue-100' : 'text-gray-500'
                        }`}>
                          {messageDate.toLocaleTimeString('he-IL', { 
                            hour: '2-digit', 
                            minute: '2-digit' 
                          })}
                        </div>

                        {message.role === 'assistant' && (
                          <div className="flex items-center gap-4 mt-4 pt-4 border-t border-gray-100">
                            <button
                              onClick={() => handleSaveInsight(message)}
                              className="flex items-center text-blue-600 hover:text-blue-700 transition-colors"
                            >
                              <Save className="h-5 w-5 ml-2" />
                              <span>שמור תובנה</span>
                            </button>

                            <button
                              onClick={() => handleExportPDF(message)}
                              className="flex items-center text-blue-600 hover:text-blue-700 transition-colors"
                            >
                              <FileText className="h-5 w-5 ml-2" />
                              <span>שמור כ-PDF</span>
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              </React.Fragment>
            );
          })}
          {loading && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex justify-start"
            >
              <div className="max-w-[85%] w-full">
                <LoadingMessage />
              </div>
            </motion.div>
          )}
        </div>

        {error && (
          <div className="px-4 py-3 bg-red-50 border-t border-red-100">
            <p className="text-red-600 text-sm">{error}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-4 bg-white border-t border-gray-100">
          <div className="flex gap-3">
            <input
              ref={inputRef}
              type="text"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder={chatMessages.length > 0 ? "שאל שאלת המשך..." : "שאל את היועץ החכם..."}
              className="flex-1 px-6 py-4 text-lg border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
              disabled={loading}
              dir="rtl"
            />
            <button
              type="submit"
              disabled={loading || !question.trim()}
              className="bg-gradient-to-r from-blue-600 to-blue-700 text-white py-2 px-6 rounded-xl hover:shadow-lg transition-all duration-200 disabled:opacity-50 flex items-center justify-center min-w-[60px]"
            >
              <Send className="h-6 w-6" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export { AskAdvisor }