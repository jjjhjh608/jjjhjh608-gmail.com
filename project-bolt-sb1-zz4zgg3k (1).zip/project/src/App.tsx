import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { Dashboard } from './pages/Dashboard';
import { SmartReport } from './pages/SmartReport';
import { AskAdvisor } from './pages/AskAdvisor';
import { MyInsights } from './pages/MyInsights';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { useAppStore } from './store';
import { supabase } from './lib/supabase';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="smart-report" element={<SmartReport />} />
          <Route path="ask-advisor" element={<AskAdvisor />} />
          <Route path="my-insights" element={<MyInsights />} />
          <Route path="login" element={<Login />} />
          <Route path="register" element={<Register />} />
          <Route path="auth/callback" element={<AuthCallback />} />
        </Route>
      </Routes>
    </Router>
  );
}

function AuthCallback() {
  const navigate = useNavigate();
  const { setUser } = useAppStore();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const handleCallback = async () => {
      try {
        // Get the session from the URL
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();
        
        if (sessionError) throw sessionError;

        if (session?.user) {
          // Check if user profile exists
          const { data: existingUser, error: userError } = await supabase
            .from('users')
            .select('*')
            .eq('id', session.user.id)
            .single();

          if (!existingUser && !userError) {
            // Create new user profile
            const { data: newUser, error: createError } = await supabase
              .from('users')
              .insert([
                {
                  id: session.user.id,
                  email: session.user.email,
                  full_name: session.user.user_metadata?.full_name || session.user.user_metadata?.name || 'משתמש חדש',
                  created_at: new Date().toISOString()
                }
              ])
              .select()
              .single();

            if (createError) throw createError;
            setUser(newUser);
          } else if (existingUser) {
            setUser(existingUser);
          }

          // Redirect to dashboard
          navigate('/dashboard');
        } else {
          throw new Error('לא נמצא משתמש בסשן');
        }
      } catch (err) {
        console.error('Error in auth callback:', err);
        setError(err instanceof Error ? err.message : 'שגיאה באימות');
      }
    };

    handleCallback();
  }, [navigate, setUser]);

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="bg-red-50 text-red-600 p-4 rounded-xl">
          {error}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
        <p className="text-gray-600">מאמת את החשבון שלך...</p>
      </div>
    </div>
  );
}

export default App;