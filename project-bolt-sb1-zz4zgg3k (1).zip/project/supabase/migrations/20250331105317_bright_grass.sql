/*
  # Add missing fields to business_profiles table

  1. New Fields
    - `age_range` (text) - Age range of clients
    - `gender_focus` (text) - Gender focus of target audience
    - `promotion_methods` (text[]) - Current business promotion methods
    - `sales_challenges` (text) - Challenges in sales
    - `income_sources` (text[]) - Main income sources
    - `received_investments` (boolean) - Whether business received investments
    - `plan_fundraising` (boolean) - Whether business plans to raise funds

  2. Changes
    - Add new fields to business_profiles table
    - Maintain existing RLS policies
*/

ALTER TABLE business_profiles
ADD COLUMN IF NOT EXISTS age_range text,
ADD COLUMN IF NOT EXISTS gender_focus text,
ADD COLUMN IF NOT EXISTS promotion_methods text[],
ADD COLUMN IF NOT EXISTS sales_challenges text,
ADD COLUMN IF NOT EXISTS income_sources text[],
ADD COLUMN IF NOT EXISTS received_investments boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS plan_fundraising boolean DEFAULT false;