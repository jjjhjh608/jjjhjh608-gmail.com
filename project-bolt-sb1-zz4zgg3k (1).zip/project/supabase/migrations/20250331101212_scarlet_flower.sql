/*
  # Initial schema setup for Smart Business Advisor

  1. New Tables
    - `users`
      - `id` (uuid, primary key)
      - `email` (text, unique)
      - `full_name` (text)
      - `created_at` (timestamp)
      - `is_pro` (boolean)
      - `last_tip_date` (timestamp)
      - `last_tip` (text)

    - `business_profiles`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key)
      - All business profile fields
      - Timestamps

    - `chat_messages`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key)
      - `content` (text)
      - `role` (text)
      - `created_at` (timestamp)

    - `business_reports`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key)
      - All report fields
      - `created_at` (timestamp)

    - `saved_insights`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key)
      - `content` (text)
      - `type` (text)
      - `created_at` (timestamp)

    - `daily_tips`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key)
      - `content` (text)
      - `is_useful` (boolean)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to access their own data
*/

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  full_name text NOT NULL,
  created_at timestamptz DEFAULT now(),
  is_pro boolean DEFAULT false,
  last_tip_date timestamptz,
  last_tip text
);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Business Profiles table
CREATE TABLE IF NOT EXISTS business_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  business_name text,
  business_sector text,
  establishment_date date,
  employees_partners text,
  unique_value text,
  target_customers text,
  customer_retention text,
  customer_location text,
  marketing_channels text[],
  best_marketing_channel text,
  sales_funnel text,
  monthly_customers integer DEFAULT 0,
  marketing_budget text,
  monthly_revenue numeric DEFAULT 0,
  fixed_expenses text,
  variable_expenses text,
  is_profitable boolean DEFAULT false,
  has_debts boolean DEFAULT false,
  time_management text,
  management_tools text[],
  optimization_needs text,
  main_challenges text,
  stuck_areas text,
  improvement_attempts text,
  investment_willingness text,
  investment_amount text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE business_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own business profile"
  ON business_profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own business profile"
  ON business_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own business profile"
  ON business_profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Chat Messages table
CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  content text NOT NULL,
  role text NOT NULL CHECK (role IN ('assistant', 'user')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own chat messages"
  ON chat_messages
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own chat messages"
  ON chat_messages
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Business Reports table
CREATE TABLE IF NOT EXISTS business_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  business_name text NOT NULL,
  business_type text NOT NULL,
  target_audience text NOT NULL,
  monthly_revenue numeric NOT NULL,
  marketing_budget numeric NOT NULL,
  business_goals text NOT NULL,
  analysis jsonb NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE business_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own business reports"
  ON business_reports
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own business reports"
  ON business_reports
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Saved Insights table
CREATE TABLE IF NOT EXISTS saved_insights (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  content text NOT NULL,
  type text NOT NULL CHECK (type IN ('tip', 'qa', 'report')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE saved_insights ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own saved insights"
  ON saved_insights
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own saved insights"
  ON saved_insights
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Daily Tips table
CREATE TABLE IF NOT EXISTS daily_tips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  content text NOT NULL,
  is_useful boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE daily_tips ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own daily tips"
  ON daily_tips
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own daily tips"
  ON daily_tips
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);